const cv=document.getElementById('c'),g=cv.getContext('2d'),W=960,H=540;
const CH=[
{n:'Fuego',col:'#ff5a3c',sp:4.2,jp:12,w:1,ad:8,ak:7,cd:26,fn:'LLUVIA DE METEOROS',d:'Equilibrado · fuego y explosiones',m:'Bola de fuego · Llamarada · Fénix · Erupción',
 mv:{N:['proj',{v:8,d:6,k:5,l:70,r:9,col:'#ff8a2a'}],S:['spray',{d:2,k:2,r:6,col:'#ffb02a'}],U:['up',{h:12,fr:16,d:7,k:8}],D:['slam',{d:11,k:10,r:55}]}},
{n:'Rayo',col:'#ffd23c',sp:5.6,jp:13,w:.8,ad:5,ak:5,cd:16,fn:'TORMENTA ELÉCTRICA',d:'Veloz y ligero · electricidad',m:'Chispas · Rayo del cielo · Relámpago ascendente · Carga estática',
 mv:{N:['spread',{v:12,d:3,k:3,l:35,r:6,col:'#fff36b'}],S:['bolt',{d:9,k:8,r:40,col:'#fff36b'}],U:['tup',{dy:-170,d:5,k:6}],D:['mine',{d:9,k:8,r:14,col:'#fff36b'}]}},
{n:'Roca',col:'#8e9bb5',sp:3,jp:10.5,w:1.5,ad:12,ak:10,cd:36,fn:'CATACLISMO',d:'Lento y pesado · golpes brutales',m:'Peñasco · Roca rodante · Salto sísmico · Terremoto',
 mv:{N:['proj',{v:5,vy:-3,g:.15,d:10,k:9,l:90,r:15,col:'#aab3c7'}],S:['proj',{v:6,d:12,k:11,l:80,r:16,col:'#8e9bb5',gy:1,pi:1}],U:['leap',{d:9,k:10}],D:['quake',{v:6,d:10,k:10,l:60,r:14,col:'#aab3c7'}]}},
{n:'Hielo',col:'#6fe0ff',sp:4.5,jp:12,w:.9,ad:7,ak:6,cd:22,fn:'VENTISCA',d:'Control · congela al rival',m:'Carámbanos · Deslizamiento · Ascenso helado · Zona gélida',
 mv:{N:['rain',{d:4,k:2,r:9,l:90,col:'#bdf3ff',st:25}],S:['dash',{v:16,d:5,k:3,fr:10,st:30}],U:['up',{h:10,fr:16,d:5,k:6,st:25}],D:['frost',{r:150,st:30,d:4}]}},
{n:'Sombra',col:'#9a5cff',sp:5,jp:12.5,w:.85,ad:6,ak:6,cd:18,fn:'ECLIPSE',d:'Sigiloso · teletransportes',m:'Orbes teledirigidos · Paso sombra · Salto umbrío · Velo veloz',
 mv:{N:['proj',{v:6,d:5,k:5,l:110,r:7,col:'#d6b8ff',hm:1}],S:['tele',{v:230,d:8,k:7}],U:['tup',{dx:110,dy:-130,d:6,k:7}],D:['buff',{fr:220}]}},
{n:'Selva',col:'#4fd36a',sp:3.8,jp:11.5,w:1.2,ad:9,ak:8,cd:28,fn:'ENREDADERA GIGANTE',d:'Resistente · se cura',m:'Zarzas · Látigo · Liana curativa · Fotosíntesis',
 mv:{N:['thorn',{d:7,k:5,r:26,col:'#8cf08c'}],S:['whip',{r:150,d:9,k:8}],U:['up',{h:10,fr:18,d:6,k:7,hl:6}],D:['heal',{h:15}]}},
{n:'Viento',col:'#b8f2e6',sp:5.8,jp:13.5,w:.7,ad:5,ak:5,cd:15,fn:'TORNADOS',d:'Ultraligero · empuja y atrae',m:'Ráfaga serpenteante · Remolino · Planeo · Ojo de la tormenta',
 mv:{N:['proj',{v:9,d:3,k:7,l:70,r:12,col:'#e0fff8',sn:1}],S:['pull',{}],U:['glide',{}],D:['shield',{}]}},
{n:'Ninja',col:'#ff4d6d',sp:5.2,jp:12.5,w:.9,ad:7,ak:6,cd:18,fn:'MIL CORTES',d:'Técnico · shuriken y cortes',m:'Shuriken boomerang · Tajo trasero · Salto diagonal · Abanico de shuriken',
 mv:{N:['proj',{v:13,d:4,k:4,l:60,r:6,col:'#eeeeee',bo:1}],S:['back',{d:10,k:9}],U:['up',{h:9,fr:16,vx:8,d:6,k:7}],D:['fan',{v:11,d:3,k:3,l:35,r:5,col:'#eeeeee'}]}},
{n:'Astro',col:'#ff9ee5',sp:3.6,jp:11,w:1.3,ad:10,ak:9,cd:30,fn:'SUPERNOVA',d:'Cósmico · orbes y cometas',m:'Planeta perforante · Cometa · Ascenso gravitatorio · Colapso',
 mv:{N:['proj',{v:4,d:8,k:7,l:140,r:20,col:'#c9a3ff',pi:1}],S:['comet',{d:8,k:8,r:16,l:90,col:'#ffe066'}],U:['up',{h:10,fr:18,d:7,k:8,pl:1}],D:['grav',{d:6,st:18}]}},
{n:'Vacío',col:'#4b3f72',sp:4,jp:12,w:1.2,ad:9,ak:7,cd:30,fn:'EL GRAN APAGÓN',d:'',m:'',
 mv:{N:['nova',{v:5,d:6,k:5,l:42,r:11,col:'#2a1a4a'}],S:['swap',{}],U:['over',{d:7,k:7}],D:['drain',{r:150,d:6,k:5}]}},
{n:'Agua',col:'#3d8bff',sp:4.7,jp:12,w:1,ad:7,ak:6,cd:20,fn:'MAREMOTO',d:'Fluido · olas y embestidas',m:'Burbuja de marea · Tabla de espuma · Géiser · Corriente de fondo',
 mv:{N:['bubble',{v:5,d:5,k:3,l:100,r:14,col:'#a9ecff',st:28,pi:1,hm:1}],S:['surf',{v:12,d:6,k:6,fr:18}],U:['fountain',{h:13,fr:20,d:7,k:7}],D:['tide',{v:9,d:7,k:7,l:78,r:17,col:'#3d8bff',pi:1}]}},
{n:'Veneno',col:'#b6e02f',sp:4.3,jp:12,w:1,ad:6,ak:5,cd:20,fn:'PANTANO MORTAL',d:'Sucio · envenena con el tiempo',m:'Baba corrosiva · Estanque ácido · Estallido de esporas · Espinas tóxicas',
 mv:{N:['glob',{v:7,vy:-4,g:.16,d:5,k:4,l:86,r:11,col:'#c8ef45',ps:1,st:10}],S:['pool',{d:3,k:2,r:31,col:'#b6e02f',ps:1,repeat:1}],U:['spores',{d:4,k:2,r:7,col:'#d9ff68',ps:1}],D:['eruption',{d:7,k:6,r:13,col:'#b6e02f',ps:1}]}},
{n:'Acero',col:'#d9dde6',sp:3.4,jp:11,w:1.4,ad:11,ak:9,cd:32,fn:'LLUVIA DE ESPADAS',d:'Blindado · cortes perforantes',m:'Filo perseguidor · Ariete blindado · Ascenso magnético · Yunque sísmico',
 mv:{N:['blade',{v:11,d:6,k:5,l:90,r:7,col:'#e7f0ff',pi:1,bo:1}],S:['ram',{v:13,d:10,k:10,fr:13}],U:['magnetrise',{h:15,d:8,k:8}],D:['anvil',{d:13,k:12,r:64}]}},
{n:'Luz',col:'#fff6c9',sp:5.2,jp:12.5,w:.85,ad:6,ak:6,cd:18,fn:'AMANECER',d:'Radiante · curación y rayos',m:'Rayo prismático · Espejo solar · Alba ascendente · Renovación',
 mv:{N:['prism',{v:10,d:5,k:4,l:62,r:8,col:'#fff6c9',pi:1,ref:1}],S:['mirror',{d:8,k:8}],U:['sunrise',{d:7,k:7}],D:['renewal',{h:18}]}}];
const MAPS=[
{n:'Cumbre',p:[{x:230,y:390,w:500,t:0},{x:290,y:290,w:140,t:1},{x:530,y:290,w:140,t:1}],c:['#2b1d52','#d9684b','#fbe3b8','#3a2557'],g:'#6fcf6a'},
{n:'Tres islas',p:[{x:90,y:380,w:230,t:0},{x:365,y:310,w:230,t:0},{x:640,y:380,w:230,t:0},{x:430,y:190,w:100,t:1,a:70,s:.02}],c:['#0f3b57','#2fb5a5','#fff1b8','#14566e'],g:'#c9e57a'},
{n:'Volcán',p:[{x:200,y:420,w:560,t:0},{x:140,y:310,w:120,t:1},{x:420,y:250,w:120,t:1},{x:700,y:310,w:120,t:1}],c:['#1a0b12','#c2381f','#ffb347','#3d1420'],g:'#ff8f4a'},
{n:'Nubes',p:[{x:160,y:400,w:260,t:0},{x:540,y:400,w:260,t:0},{x:350,y:300,w:260,t:1,a:60,s:.02},{x:80,y:260,w:120,t:1},{x:760,y:260,w:120,t:1}],c:['#5ab0ff','#d6f0ff','#fff7d6','#a8d6ff'],g:'#ffffff'},
{n:'Ciudad neón',p:[{x:100,y:420,w:760,t:0},{x:200,y:320,w:160,t:1},{x:600,y:320,w:160,t:1},{x:400,y:230,w:160,t:1}],c:['#0b0b2a','#7a1fa2','#ff4fd8','#1a1450'],g:'#38f9ff'},
{n:'Desierto',p:[{x:100,y:400,w:300,t:0},{x:560,y:400,w:300,t:0},{x:400,y:300,w:160,t:1}],c:['#f4a259','#f7d794','#fff4c2','#c8773a'],g:'#e9c46a'},
{n:'Espacio',p:[{x:330,y:400,w:300,t:0},{x:90,y:300,w:150,t:1,a:60,s:.02},{x:720,y:300,w:150,t:1,a:60,s:-.02},{x:405,y:215,w:150,t:1}],c:['#05061a','#2a1b5e','#b9c7ff','#17123a'],g:'#9fb4ff'},
{n:'Templo en ruinas',p:[{x:180,y:410,w:600,t:0},{x:230,y:310,w:140,t:1},{x:590,y:310,w:140,t:1},{x:410,y:220,w:140,t:1,a:90,s:.025}],c:['#3b2a1a','#e8a35a','#ffe6a8','#5a3a22'],g:'#b7c46a'},
{n:'Aurora glaciar',p:[{x:120,y:410,w:300,t:0},{x:540,y:410,w:300,t:0},{x:330,y:320,w:300,t:1,a:40,s:.03},{x:400,y:210,w:160,t:1}],c:['#0b2a4a','#5ec8e8','#e8fbff','#2d6a8f'],g:'#e8fbff'},
{n:'Bosque encantado',p:[{x:150,y:410,w:660,t:0},{x:100,y:300,w:140,t:1},{x:720,y:300,w:140,t:1},{x:410,y:240,w:140,t:1}],c:['#0d2a1a','#2f7a4a','#e6f5a0','#14402a'],g:'#7ee06a'},
{n:'Mar de cristal',p:[{x:120,y:410,w:260,t:0},{x:580,y:410,w:260,t:0},{x:330,y:320,w:300,t:1,a:50,s:.025},{x:410,y:220,w:140,t:1}],c:['#062a5c','#2f7fd6','#bfe9ff','#0e3f80'],g:'#9fe6ff'},
{n:'Pantano tóxico',p:[{x:140,y:410,w:680,t:0},{x:200,y:310,w:130,t:1,a:30,s:.03},{x:630,y:310,w:130,t:1,a:30,s:-.03},{x:415,y:230,w:130,t:1}],c:['#1b2a0a','#6a8f1a','#eaff9a','#2a3d10'],g:'#b6e02f'},
{n:'Fortaleza de acero',p:[{x:210,y:410,w:540,t:0},{x:90,y:300,w:150,t:1},{x:720,y:300,w:150,t:1},{x:300,y:240,w:100,t:1,a:80,s:.02},{x:560,y:240,w:100,t:1,a:80,s:-.02}],c:['#1a1d26','#4a5568','#ffd9a0','#2a2f3d'],g:'#aab6c8'},
{n:'Santuario del Alba',p:[{x:180,y:410,w:600,t:0},{x:140,y:290,w:130,t:1},{x:690,y:290,w:130,t:1},{x:410,y:200,w:140,t:1,a:100,s:.02}],c:['#2a1050','#ff9bd0','#fff6c9','#4a1f7a'],g:'#fff6c9'}];
MAPS.forEach(m=>m.p.forEach(l=>{l.ox=l.x}));
let PL=MAPS[0].p,FX=[];
function burst(x,y,col,n=10,speed=4){for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,v=.8+Math.random()*speed;FX.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-1,life:18+Math.random()*20,max:38,col,r:2+Math.random()*3})}}
function doSp(p,o,m){X.sp(p);const[t,q]=m,f=p.f,cx=p.x+p.w/2;p.pose=t;p.poseT=Math.max(p.poseT||0,22);burst(cx+f*14,p.y+24,p.c.col,12,3.8);
 if(['proj','bubble','glob','blade','prism'].includes(t))B.push({x:cx+f*20,y:p.y+(q.gy?p.h-q.r:18),vx:f*q.v,vy:q.vy||0,o:p,l:q.l,q,dl:0});
 else if(t=='spread')for(const a of[-3,0,3])B.push({x:cx+f*20,y:p.y+18,vx:f*q.v,vy:a,o:p,l:q.l,q,dl:0});
 else if(t=='mine')B.push({x:cx,y:p.y+p.h-10,vx:0,vy:0,o:p,l:420,q,dl:0});
 else if(t=='dash'||t=='surf'||t=='ram'){p.dash=q.fr||12;p.dq=q;p.pose=t;p.poseT=q.fr||18;if(t=='ram')p.armor=18}
 else if(t=='up'){p.up=q.fr||16;p.uq=q;p.jm=2;if(q.hl)p.dmg=Math.max(0,p.dmg-q.hl);if(q.pl&&Math.abs(o.x-p.x)<320){o.vx=(p.x>o.x?1:-1)*9;o.stun=Math.max(o.stun,10)}}
 else if(t=='slam'){p.slam=16;p.sq=q}
 else if(t=='tele'){p.x=Math.max(20,Math.min(W-54,p.x+f*q.v));p.vy=0;p.inv=Math.max(p.inv,12);p.tp=10;p.tq=q}
 else if(t=='rain')for(const a of[-70,0,70])B.push({x:o.x+o.w/2+a,y:-20-Math.abs(a),vx:0,vy:7,o:p,l:90,q});
 else if(t=='pull'){if(Math.abs(o.y-p.y)<70&&Math.abs(o.x-p.x)<380&&Math.sign(o.x-p.x)==f){o.vx=-f*13;o.stun=Math.max(o.stun,14)}}
 else if(t=='shield'){p.inv=Math.max(p.inv,70);p.sc=160}
 else if(t=='buff'){p.buf=q.fr;p.sc=240}
 else if(t=='spray')for(let i=0;i<5;i++)B.push({x:cx+f*20,y:p.y+18+(i-2)*4,vx:f*(8+i),vy:(i-2)*.4,o:p,l:14+i*2,q,dl:i*3});
 else if(t=='bolt')for(let i=0;i<7;i++)B.push({x:o.x+o.w/2,y:i*80+10,vx:0,vy:0,o:p,l:36,q,dl:28});
 else if(t=='whip'){const bx=f>0?p.x+p.w:p.x-q.r;if(Math.abs(o.y-p.y)<60&&o.x+o.w>bx&&o.x<bx+q.r)hit(o,q.d,q.k,f)}
 else if(t=='back'){const s=p.x<o.x?1:-1;p.x=Math.max(20,Math.min(W-54,o.x+s*46));p.f=-s;if(o.gr)p.y=o.y;p.vy=0;p.inv=Math.max(p.inv,12);p.tp=10;p.tq=q}
 else if(t=='comet'){const s=o.x<W/2?1:-1,ty=Math.max(15,(o.y+25)/9|0);B.push({x:o.x+17+s*7*ty,y:-30,vx:-s*7,vy:9,o:p,l:90,q,dl:0})}
 else if(t=='swap'){const x=p.x,y=p.y;p.x=o.x;p.y=o.y;o.x=x;o.y=y;o.vx=o.vy=0;o.stun=Math.max(o.stun,12);p.inv=Math.max(p.inv,10)}
 else if(t=='nova')for(let i=0;i<8;i++){const a=i*Math.PI/4;B.push({x:cx,y:p.y+25,vx:Math.cos(a)*q.v,vy:Math.sin(a)*q.v,o:p,l:q.l,q,dl:0})}
 else if(t=='thorn')B.push({x:o.x+o.w/2,y:o.y+o.h-10,vx:0,vy:0,o:p,l:62,q,dl:22});
 else if(t=='quake')for(const s of[-1,1])B.push({x:cx+s*20,y:p.y+p.h-q.r,vx:s*q.v,vy:0,o:p,l:q.l,q,dl:0});
 else if(t=='frost'){if(Math.hypot(o.x-p.x,o.y-p.y)<q.r){o.stun=Math.max(o.stun,q.st);o.dmg+=q.d;o.vx=0}}
 else if(t=='fan')for(let i=-2;i<=2;i++)B.push({x:cx+f*20,y:p.y+18,vx:f*q.v,vy:i*2.2,o:p,l:q.l,q,dl:0});
 else if(t=='grav'){if(Math.abs(o.x-p.x)<340){o.vy=16;o.vx*=.2;o.stun=Math.max(o.stun,q.st);o.dmg+=q.d;sfx('hit')}}
 else if(t=='drain'){if(Math.hypot(o.x-p.x,o.y-p.y)<q.r){hit(o,q.d,q.k,Math.sign(o.x-p.x)||1);p.dmg=Math.max(0,p.dmg-q.d)}}
 else if(t=='tup'){p.x=Math.max(20,Math.min(W-54,p.x+f*(q.dx||0)));p.y=Math.max(-40,p.y+q.dy);p.vy=0;p.jm=2;p.inv=Math.max(p.inv,12);p.tp=12;p.tq=q}
 else if(t=='leap'){p.vy=-13;p.vx=f*4.5;p.jm=2;p.tp=22;p.tq=q}
 else if(t=='glide'){p.vy=-11;p.gl=100;p.jm=2}
 else if(t=='over'){p.x=Math.max(20,Math.min(W-54,o.x));p.y=Math.max(-40,o.y-130);p.vy=0;p.jm=2;p.inv=Math.max(p.inv,12);p.tp=14;p.tq=q}
 else if(t=='heal'){p.dmg=Math.max(0,p.dmg-q.h);p.inv=Math.max(p.inv,30);p.sc=240}
 else if(t=='tide'){for(let i=0;i<2;i++)B.push({x:cx+f*(24+i*18),y:p.y+p.h-13,vx:f*(q.v-i*2),vy:0,o:p,l:q.l-i*12,q:{...q,kind:'wave',r:q.r-i*3},dl:i*8})}
 else if(t=='fountain'){p.up=q.fr;p.uq=q;p.jm=2;p.vy=-q.h;p.pose=t;p.poseT=28;for(let i=-1;i<=1;i++)B.push({x:cx+i*24,y:p.y+p.h-8,vx:i*1.6,vy:-8-Math.abs(i),o:p,l:34,q:{kind:'waterjet',d:4,k:3,r:9,col:'#8deaff',g:.38,pi:1},dl:0})}
 else if(t=='pool')B.push({x:o.x+o.w/2,y:o.y+o.h-8,vx:0,vy:0,o:p,l:230,q:{...q,kind:'pool'},dl:18});
 else if(t=='spores'){p.vy=-12;p.vx=p.f*3;p.jm=2;p.pose=t;p.poseT=24;for(let i=0;i<7;i++){const a=Math.PI*(.12+i*.11);B.push({x:cx,y:p.y+8,vx:Math.cos(a)*p.f*(4+i%3),vy:-Math.sin(a)*(5+i%3),o:p,l:70,q:{...q,kind:'spore',g:.11},dl:i*2})}}
 else if(t=='eruption'){for(let i=-2;i<=2;i++)B.push({x:cx+i*13,y:p.y+p.h-8,vx:i*1.5,vy:-11-Math.abs(i),o:p,l:40,q:{...q,kind:'toxic-spike',g:.22,r:10},dl:Math.abs(i)*4})}
 else if(t=='magnetrise'){p.vy=-q.h;p.vx=(o.x>p.x?1:-1)*5;p.jm=2;p.inv=Math.max(p.inv,12);p.tp=18;p.tq=q;p.pose=t;p.poseT=26;p.armor=20}
 else if(t=='anvil'){p.vy=4;p.vx=0;p.slam=22;p.sq=q;p.pose=t;p.poseT=28;p.armor=24}
 else if(t=='mirror'){p.inv=Math.max(p.inv,76);p.sc=190;p.pose=t;p.poseT=48}
 else if(t=='sunrise'){p.vy=-16;p.vx*=.5;p.jm=2;p.tp=18;p.tq=q;p.inv=Math.max(p.inv,12);p.pose=t;p.poseT=30;for(let i=-1;i<=1;i++)B.push({x:cx+i*15,y:p.y+15,vx:i*1.4,vy:-8,o:p,l:28,q:{kind:'sunray',d:3,k:2,r:7,col:'#fff8cb',pi:1},dl:0})}
 else if(t=='renewal'){p.dmg=Math.max(0,p.dmg-q.h);p.psn=0;p.inv=Math.max(p.inv,22);p.pose=t;p.poseT=52;for(let i=0;i<6;i++)B.push({x:cx+Math.cos(i)*26,y:p.y+Math.sin(i)*15,vx:Math.cos(i)*1.2,vy:-1.5-Math.random()*2,o:p,l:42,q:{kind:'mote',d:0,k:0,r:4,col:'#fff6c9',pi:1},dl:0})}}
const KB1={l:'KeyA',r:'KeyD',u:'KeyW',d:'KeyS',a:'KeyF',s:'KeyG',f:'KeyH'},KB2={l:'ArrowLeft',r:'ArrowRight',u:'ArrowUp',d:'ArrowDown',a:'KeyK',s:'KeyL',f:'Semicolon'};
const C=[KB1,KB2];const REMOTE_KEYS=new Set(Object.values(KB2));const blockLocalRemoteKey=c=>onlineActive&&scr=='fight'&&REMOTE_KEYS.has(c);
let CFG={pad:0,sfx:1,mus:1,vol:.6,shk:1,items:1,lang:'es',difficulty:1};
try{Object.assign(CFG,JSON.parse(localStorage.getItem('dlc')||'{}'))}catch(e){}
function applyCfg(){C[0]=KB1;C[1]=KB2}
let onlineActive=false,onlineSocket=null,onlineSlot=0,onlineMatchId=null,onlineMessage='',onlineAttempt=0,lastOnlineState=0,onlineResultSent=false,onlineReady=[false,false],onlineStarted=false;
const pslot=()=>onlineActive?(CFG.pad?onlineSlot:-1):CFG.pad?(BOT[1]&&CFG.pad==2?0:CFG.pad-1):-1;
const saveCfg=()=>{applyCfg();syncLanguage();try{localStorage.setItem('dlc',JSON.stringify(CFG))}catch(e){}};
const ctl=i=>pslot()==i?'Mando ◀▶ + X':i?'←/→ + K':'A/D + F',lbl=i=>pslot()==i?'RB':i?'Ñ':'H';
let AC=null,MG=null,mN=0,mT=0;
function au(){if(!AC){try{AC=new(window.AudioContext||window.webkitAudioContext)();MG=AC.createGain();MG.connect(AC.destination)}catch(e){}}if(AC){if(AC.state=='suspended')AC.resume();MG.gain.value=CFG.vol}}
function bl(f,d,ty,v,sl=0,dl=0,mu){if(!AC||(mu?!CFG.mus:!CFG.sfx))return;const o=AC.createOscillator(),G=AC.createGain(),t=AC.currentTime+dl;o.type=ty;o.frequency.setValueAtTime(f,t);if(sl)o.frequency.linearRampToValueAtTime(Math.max(20,f+sl),t+d);G.gain.setValueAtTime(v,t);G.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(G);G.connect(MG);o.start(t);o.stop(t+d+.02)}
function nz(d,v,dl=0,mu){if(!AC||(mu?!CFG.mus:!CFG.sfx))return;const n=AC.sampleRate*d|0,b=AC.createBuffer(1,n,AC.sampleRate),a=b.getChannelData(0);for(let i=0;i<n;i++)a[i]=(Math.random()*2-1)*(1-i/n);const s=AC.createBufferSource(),G=AC.createGain();s.buffer=b;G.gain.value=v;s.connect(G);G.connect(MG);s.start(AC.currentTime+dl)}
function spS(c){const f=CH.indexOf(c);bl(140+f*38,.3,['sawtooth','square','triangle'][f%3],.14,f%2?650:-90);nz(.15,.08)}
function sfx(n){switch(n){case'mv':bl(520,.05,'square',.1);break;case'ok':bl(440,.07,'square',.14,300);bl(660,.1,'square',.12,0,.07);break;case'jp':bl(260,.12,'square',.08,260);break;case'sw':nz(.06,.12);break;
 case'hit':nz(.1,.35);bl(170,.12,'sawtooth',.22,-100);break;case'big':nz(.2,.5);bl(110,.25,'sawtooth',.35,-80);break;case'sp':bl(180,.3,'sawtooth',.14,700);nz(.2,.1);break;
 case'sm':bl(70,.9,'sawtooth',.35,-30);bl(300,.5,'square',.12,900);nz(.7,.4);break;case'it':bl(660,.08,'square',.14);bl(990,.14,'square',.14,0,.08);break;
 case'bomb':nz(.5,.6);bl(60,.5,'sawtooth',.4,-30);break;case'ko':bl(440,.6,'sawtooth',.25,-380);nz(.4,.3);break;case'rd':[392,523,659,784].forEach((f,i)=>bl(f,.12,'square',.12,0,i*.05));break;case'sel':bl(880,.04,'triangle',.08);break;case'mag':bl(900,.25,'sawtooth',.14,-700);bl(500,.2,'square',.1,400,.1);break;case'win':[523,659,784,1047].forEach((f,i)=>bl(f,.25,'square',.15,0,i*.14))}}
const SC=[[0,3,7,12,7,3],[0,3,7,10,7,3],[-2,2,5,9,5,2],[-4,0,3,7,3,0],[0,2,5,9,7,2],[0,4,7,11,9,4],[-3,0,4,7,5,0],[-5,-1,2,7,4,-1]];
function music(){if(!AC||!CFG.mus)return;const fi=scr=='fight',bs=fi&&sty&&sty.ord&&sty.ord[sty.ch]==9,st=60/(fi?(bs?190:148+mapI%5*5):100)/2,now=AC.currentTime;if(mT<now-.5)mT=now+.05;
 while(mT<now+.15){const ch=SC[(mN>>3)%SC.length],n=mN%8,dl=mT-now,fq=r=>110*2**((r+(fi?mapI%7-3:0))/12);
  bl(fq(ch[n%6]+12),st*.9,n%3==0?'triangle':n%3==1?'sine':'square',.07,0,dl,1);if(n==2||n==6)bl(fq(ch[(n+2)%6]+24),st*.48,'triangle',.045,0,dl,1);if(n%4==0)bl(fq(ch[0]-12),st*1.8,'sawtooth',fi?.1:.06,0,dl,1);if(fi&&n%2)nz(.03,.05,dl,1);if(fi){if(n%4==0)bl(55,.12,'sine',.3,-25,dl,1);if(n%4==2)nz(.08,.12,dl,1);if(n%8==6)bl(120+mapI*9,.16,'triangle',.07,260,dl,1);if(bs&&n%2==0)bl(fq(ch[2]+24),st,'sawtooth',.04,0,dl,1)}else if(n%2==0)bl(fq(ch[(n>>1)%4]+24),st*.6,'square',.025,0,dl,1);mT+=st;mN++}}
let PP={},padSelectUntil=0;
function padSelectReady(){const now=performance.now();if(now<padSelectUntil)return false;padSelectUntil=now+260;return true}
function pollPad(){const gp=(navigator.getGamepads?[...navigator.getGamepads()]:[]).find(x=>x&&x.connected);if(!gp)return;
 const b=i=>gp.buttons[i]&&gp.buttons[i].pressed,x=gp.axes[0]||0,y=gp.axes[1]||0,sl=pslot(),sel_=scr=='sel',confirm=b(1),confirmEdge=confirm&&!PP.padB;PP.padB=confirm;
 const st={l:x<-.5||b(14),r:x>.5||b(15),u:(scr=='fight'&&b(0))||b(12)||(y<-.8&&-y>Math.abs(x)*1.6),d:y>.6||b(13),a:b(2),s:b(3),f:b(4)||b(5)||b(6)||b(7)};
 const n={};if(scr!='fight'&&!sel_){n.ArrowLeft=st.l;n.ArrowRight=st.r;n.ArrowUp=st.u;n.ArrowDown=st.d;n.Enter=confirm}
 n.Escape=b(8);
 for(const k in n){const v=!!n[k];if(v&&!PP['n'+k]){if(k!='Enter'||padSelectReady()){J[k]=1;au()}}PP['n'+k]=v}
 if(sel_&&confirmEdge&&padSelectReady()){const player=sl<0?0:sl;J[onlineActive?KB1.a:C[player].a]=1;au()}
 if(sl<0||scr!='fight'&&!sel_)return;
 for(const a in st){if(sel_&&a=='a')continue;const code=onlineActive?KB1[a]:C[sl][a],v=!!st[a];if(onlineActive&&scr=='fight'&&sl==onlineSlot&&v!=!!PP[a])onlineSend({type:'input',key:a,down:v});if(v&&!PP[a]){J[code]=1;au()}if(v)K[code]=1;else if(PP[a])K[code]=0;PP[a]=v}}
function rum(t,d){if(!CFG.pad||t.i!=pslot())return;try{const gp=[...navigator.getGamepads()].find(x=>x&&x.connected);gp&&gp.vibrationActuator&&gp.vibrationActuator.playEffect('dual-rumble',{duration:120,strongMagnitude:Math.min(1,d/20),weakMagnitude:.5})}catch(e){}}
const K={};let J={};
addEventListener('keydown',e=>{au();const c=e.code=='ShiftRight'?'ShiftLeft':e.code;if(c.startsWith('Arrow')||c=='Space')e.preventDefault();if(blockLocalRemoteKey(c))return;const was=!!K[c];if(!e.repeat)J[c]=1;K[c]=1;if(!e.repeat&&!was&&onlineActive&&scr=='fight'){const key=Object.keys(KB1).find(k=>KB1[k]==c);if(key)onlineSend({type:'input',key,down:true})}});
addEventListener('keyup',e=>{const c=e.code=='ShiftRight'?'ShiftLeft':e.code;if(blockLocalRemoteKey(c))return;if(K[c]&&onlineActive&&scr=='fight'){const key=Object.keys(KB1).find(k=>KB1[k]==c);if(key)onlineSend({type:'input',key,down:false})}K[c]=0});function menuClick(e){au();if(scr!='menu')return;const rect=cv.getBoundingClientRect(),x=(e.clientX-rect.left)*W/rect.width,y=(e.clientY-rect.top)*H/rect.height;if(x<0||x>W||y<0||y>H)return;if(y<74&&x>790){scr='set';sfx('ok');return}if(menuPage=='root'){if(y>=145)chooseGroup(x<480?0:1);return}if(menuPage=='transition')return;if(y<155||y>480)return;const list=menuPage=='solo'?SOLO:DUO,rows=Math.ceil((list.length+1)/2),col=x<480?0:1,row=Math.max(0,Math.floor((y-164)/(314/rows))),index=row*2+col;if(index<list.length+1){mi=index;chooseMode(index)}}addEventListener('pointerdown',menuClick);cv.addEventListener('pointerdown',e=>{if(scr!='set')return;const rect=cv.getBoundingClientRect(),x=(e.clientX-rect.left)*W/rect.width,y=(e.clientY-rect.top)*H/rect.height;if(y>=387&&y<=423&&x>=525&&x<=715){si=7;CFG.difficulty=Math.max(0,Math.min(3,Math.round((x-525)/190*3)));saveCfg();sfx('ok')}});
let scr='menu',sel=[0,2],BOT=[0,0],sty=null,mi=0,menuPage='root',menuTarget='solo',menuPunch=0,menuAnim=0,clock=0,LV=1,dl=[],di=0,dn=null,dc=0,rdy=[0,0],P=[],B=[],shake=0,win=null,HZ=[],fs=null,A=null,mapI=0,M=MAPS[0],IS=[],itT=300,MD={k:'vs',st:3,g:1,it:380},SV=0,T=0,cdn=0,yaT=0,fr=0;
const mk=i=>({i,x:i?640:300,y:100,w:34,h:50,vx:0,vy:0,f:i?-1:1,c:CH[sel[i]],dmg:0,fs:0,up:0,uu:0,buf:0,pw:0,ty:'F',tp:0,dq:0,uq:0,sq:0,st:MD.st,ph:0,jm:0,cd:0,sc:0,stun:0,inv:90,act:0,hd:0,dash:0,slam:0,drop:0,gr:0,on:null,armor:0,pose:'',poseT:0,score:0,king:0});
function start(){PL=MAPS[mapI].p;PL.forEach(l=>{l.x=l.ox;l.dx=0});cdn=180;yaT=0;fr=0;P=[mk(0),mk(1)];B=[];HZ=[];FX=[];IS=[];itT=300;clock=MD.limit||0;fs=null;PL=MAPS[mapI].p;M=MAPS[mapI];scr='fight';win=null}
const ov=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
function hit(t,d,kb,dir){if(t.inv>0)return;X.hit(t,d);if(A&&A.pw>0){d*=1.5;kb*=1.3}if(A&&A!==t)A.score=(A.score||0)+d;t.dmg+=d;sfx(d>12?'big':'hit');rum(t,d);t.fs=Math.min(100,t.fs+d*.8);if(A)A.fs=Math.min(100,A.fs+d*1.6);const k=(kb+t.dmg*.1)/t.c.w;
 if(t.armor>0){t.vx=dir*k*.18;t.vy=Math.min(t.vy,-1)}else{t.vx=dir*k;t.vy=-k*.6-3;t.stun=Math.min(40,10+k*1.2|0);t.dash=t.slam=t.act=t.up=0}shake=7;burst(t.x+t.w/2,t.y+t.h/2,d>12?'#fff':'#ffd18c',7,3)}
function upd(p,o){const k=onlineActive?(p.i==onlineSlot?KB1:KB2):C[p.i],c=p.c;A=p;
 ['cd','sc','inv','drop','buf','pw','gl','psn','armor','poseT'].forEach(n=>{if(p[n]>0)p[n]--});if(p.psn>0)p.dmg+=.03;
 const dir=o.x>p.x?1:-1;
 if(p.stun>0){p.stun--;p.vx*=.98}
 else{
  const m=(K[k.r]?1:0)-(K[k.l]?1:0);
  if(p.dash>0){p.dash--;p.vx=p.f*p.dq.v;p.vy=0}
  else if(p.slam>0){p.slam--;p.vx=0;p.vy=Math.max(p.vy,6)}
  else if(p.up>0){p.up--;p.vy=-p.uq.h;p.vx=p.uq.vx?p.f*p.uq.vx:p.vx*.9+((K[k.r]?1:0)-(K[k.l]?1:0))*.5;if(!p.up){p.vy=-3;if(p.uq.vx)p.vx*=.4}}
  else{
   if(m){p.f=m;p.vx+=(m*c.sp*(p.buf>0?1.6:1)-p.vx)*.25}else p.vx*=p.gr?.75:.95;
   if(J[k.u]&&p.jm<2){p.vy=-c.jp*(p.jm?.9:1);p.jm++;p.gr=0;sfx('jp')}
   if(J[k.d]&&p.gr&&p.on&&p.on.t){p.drop=14;p.y+=3;p.gr=0}
   if(J[k.f]&&p.fs>=100)fsGo(p,o);if(J[k.a]&&!p.cd&&!p.act){p.ty=K[k.u]?'U':(!p.gr&&K[k.d])?'D':'F';p.act=14;p.hd=0;p.cd=c.cd;sfx('sw')}
   if(J[k.s]&&!p.sc){p.sc=70;p.hd=0;spS(c);
    if(K[k.u]&&!p.uu){p.uu=1;doSp(p,o,c.mv.U)}
    else if(K[k.d])doSp(p,o,c.mv.D);
    else if(m)doSp(p,o,c.mv.S);
    else doSp(p,o,c.mv.N)}
  }
 }
 // golpes
 if(p.act>0){p.act--;if(p.act<=10&&p.act>=4&&!p.hd){
  const b=abox(p);
  if(ov(b,o)){const ok=o.inv<=0;hit(o,c.ad*(p.ty=='F'?1:.9),c.ak,p.ty=='U'?0:p.f);if(ok){if(p.ty=='D'){o.vy=13;o.vx*=.3}else if(p.ty=='U')o.vy-=4}p.hd=1}}}
 if(p.dash>0&&!p.hd&&ov({x:p.x-6,y:p.y-4,w:p.w+12,h:p.h+8},o)){hit(o,p.dq.d,p.dq.k,p.f);if(p.dq.st)o.stun=Math.min(60,o.stun+p.dq.st);p.hd=1}
 if(p.tp>0){p.tp--;if(!p.hd&&ov({x:p.x-10,y:p.y-10,w:p.w+20,h:p.h+20},o)){hit(o,p.tq.d,p.tq.k,p.f);p.hd=1}}
 if(p.up>0&&!p.hd&&ov({x:p.x-8,y:p.y-24,w:p.w+16,h:p.h+30},o)){hit(o,p.uq.d,p.uq.k,dir);if(p.uq.st)o.stun=Math.min(60,o.stun+p.uq.st);p.hd=1}
 if(p.slam>0&&p.slam<=10&&!p.hd&&ov({x:p.x-p.sq.r,y:p.y-10,w:p.w+2*p.sq.r,h:p.h+20},o)){hit(o,p.sq.d,p.sq.k,dir);p.hd=1}
 // física
 if(!p.dash)p.vy=Math.min(p.vy+.6*MD.g*(p.gl>0?.25:1),(K[k.d]&&!p.gr)?18:14);
 if(p.on&&p.on.dx)p.x+=p.on.dx;p.x+=p.vx;const prev=p.y+p.h;p.y+=p.vy;p.gr=0;p.on=null;
 if(p.vy>=0&&!p.drop)for(const l of PL)
  if(p.x+p.w>l.x&&p.x<l.x+l.w&&prev<=l.y+1&&p.y+p.h>=l.y){p.y=l.y-p.h;if(p.vy>9)nz(.05,.12);p.vy=0;p.gr=1;p.jm=0;p.uu=0;p.on=l;break}
 if(p.x<-120||p.x>W+120||p.y>H+120||p.y<-330){
  p.st--;shake=12;sfx('ko');
  if(p.st<=0){scr='end';win=o;sfx('win');X.end(win)}
  else{p.x=W/2-17;p.y=60;p.vx=p.vy=0;p.dmg=0;p.inv=100;p.stun=0;p.jm=0;p.uu=0}}
}
function step(){
 if(cdn>0){cdn--;if(cdn%60==59)bl(cdn>150?520:520,.12,'square',.18);if(cdn==0){yaT=45;bl(880,.3,'square',.2,300)}return}
 if(yaT>0)yaT--;fr++;
 for(const l of PL){if(l.a){const nx=l.ox+Math.sin(fr*l.s)*l.a;l.dx=nx-l.x;l.x=nx}else l.dx=0}
 for(const f of FX){f.x+=f.vx;f.y+=f.vy;f.vy+=.12;f.life--}FX=FX.filter(f=>f.life>0);
 if(fs&&fs.t>0){fs.t--;shake=5;return}
 upd(P[0],P[1]);if(scr!='fight'){if(MD.k=='online'&&onlineActive&&onlineSlot==0&&win&&!onlineResultSent){onlineResultSent=true;onlineSend({type:'result',winner:win.i})}J={};return}if(BOT[1])ai(P[1],P[0]);upd(P[1],P[0]);
 for(const h of HZ){if(h.t>0){h.t--;continue}h.life--;h.x+=h.vx||0;const t=P[1-fs.p.i];
  if(!h.hit&&t.inv<=0&&ov(h,t)){A=null;hit(t,h.dmg,h.kb,Math.sign(t.x-h.x-h.w/2)||1);h.hit=1}}
 HZ=HZ.filter(h=>h.life>0);itemStep();
 for(const b of B){if(b.dl>0){b.dl--;continue}const q=b.q,t=P[1-b.o.i];
  if(q.hm)b.vy=Math.max(-5,Math.min(5,b.vy+Math.sign(t.y+25-b.y)*.35));
  if(q.bo&&b.l==q.l>>1)b.vx=-b.vx;if(q.ref&&b.l%18==0)b.vy=-b.vy;
  if(q.sn)b.vy=Math.sin(b.l*.35)*4;
  b.x+=b.vx;b.vy+=q.g||0;b.y+=b.vy;b.l--;
  const r=q.r;if((!b.dn||q.repeat)&&(!b.cool||b.cool<=0)&&q.d>0&&ov({x:b.x-r,y:b.y-r,w:2*r,h:2*r},t)){A=b.o;const ok=t.inv<=0;hit(t,q.d,q.k,Math.sign(b.vx)||(t.x>b.x?1:-1));if(ok&&q.st)t.stun=Math.min(60,t.stun+q.st);if(ok&&q.ps)t.psn=240;if(q.repeat)b.cool=24;else if(q.pi)b.dn=1;else b.l=0}else if(b.cool>0)b.cool--;}
 B=B.filter(b=>b.l>0&&b.x>-20&&b.x<W+20&&b.y<H+40);
 if(MD.k=='online'&&onlineActive&&onlineSlot==0&&Date.now()-lastOnlineState>80){lastOnlineState=Date.now();const fields=['x','y','vx','vy','f','dmg','fs','st','stun','inv','gr','jm','cd','sc','up','uu','buf','pw','psn','armor','act','ty','tp','dash','dq','slam','sq','drop','pose','poseT','score','king','hd'];onlineSend({type:'state',state:{players:P.map(p=>{const v={onIndex:PL.indexOf(p.on)};for(const k of fields)v[k]=p[k];return v}),bullets:B.slice(-90).map(b=>({x:b.x,y:b.y,vx:b.vx,vy:b.vy,l:b.l,dl:b.dl,owner:b.o.i,q:b.q,dn:b.dn,cool:b.cool})),hazards:HZ.slice(-50)}})}
 if(scr=='end'&&MD.k=='online'&&onlineActive&&onlineSlot==0&&!onlineResultSent){onlineResultSent=true;onlineSend({type:'result',winner:win.i})}
 if(MD.k=='king')for(const p of P)if(p.gr&&p.x+p.w/2>390&&p.x+p.w/2<570)p.king++;
 if(scr=='fight'&&clock>0&&['points','king','timer'].includes(MD.k)&&--clock<=0){const score=p=>MD.k=='king'?p.king:MD.k=='timer'?p.dmg*-1:p.score;win=score(P[0])==score(P[1])?(P[0].dmg<=P[1].dmg?P[0]:P[1]):score(P[0])>score(P[1])?P[0]:P[1];scr='end';sfx('win');X.end(win)}
 if(shake>0)shake-=.5;
}
function rr(x,y,w,h,r){g.beginPath();g.roundRect(x,y,w,h,r);g.fill()}
const EN={'DUELO EN LA CUMBRE II':'DUEL ON THE SUMMIT II','ECLIPSE DE CRISTAL':'CRYSTAL ECLIPSE','ELIGE TU DUELO':'CHOOSE YOUR SIDE','SOLITARIO · J1 VS CPU':'SOLO · P1 VS CPU','MULTIJUGADOR · P1 VS P2':'MULTIPLAYER · P1 VS P2','Dificultad de historia':'Story difficulty','Solitario':'Solo','Multijugador':'Multiplayer','Opciones':'Options','Historia':'Story','Duelo CPU':'CPU Duel','Supervivencia':'Survival','Entrenamiento':'Training','Contrarreloj':'Time Trial','Versus':'Versus','Muerte súbita':'Sudden Death','Caos total':'Total Chaos','Carrera de puntos':'Score Race','Rey de la cumbre':'King of the Hill','Caza de objetos':'Item Hunt','Volver':'Back','Ajustes':'Settings','Mando':'Controller','Efectos de sonido':'Sound effects','Música':'Music','Volumen':'Volume','Temblor de pantalla':'Screen shake','Objetos':'Items','Idioma':'Language','Español':'Spanish','Ninguno':'None','Jugador 1':'Player 1','Jugador 2':'Player 2','Sí':'On','No':'Off','Fácil':'Easy','Normal':'Normal','Difícil':'Hard','Extrema':'Extreme','Elige tu duelo':'Choose your side','Modos contra CPU':'Modes vs CPU','P1 contra P2':'P1 vs P2','J1 contra CPU':'P1 vs CPU','J1':'P1','J2':'P2','JUGADOR':'PLAYER','VEL':'SPEED','SALTO':'JUMP','FUERZA':'POWER','Elige…':'Choose…','¡LISTO!':'READY!','¡SMASH FINAL!':'FINAL SMASH!','Pulsa Enter para continuar':'Press Enter to continue','Enter para continuar ▶':'Press Enter to continue ▶','ELIGE TU PERSONAJE':'CHOOSE YOUR FIGHTER','ELIGE TU DUELO':'CHOOSE YOUR SIDE','¡A LUCHAR!':'FIGHT!','ECLIPSE DE CRISTAL':'CRYSTAL ECLIPSE','NARRADOR':'NARRATOR','Narrador':'Narrator','Recupera los 9 fragmentos':'Recover all 9 shards','Un combate contra la máquina':'A fight against the CPU','Rachas contra CPUs cada vez peores':'Endless CPU gauntlet','Práctica sin límite de vidas':'Practice with infinite lives','Supera a la CPU en 90 segundos':'Beat the CPU in 90 seconds','Combate clásico a tres vidas':'Classic three-stock battle','Una sola vida':'One life only','Gravedad lunar y objetos':'Low gravity and items','Gana quien más daño inflija':'Deal the most damage to win','Controla el centro de la arena':'Hold the center of the arena','Lluvia constante de objetos':'A constant shower of items','Nueve duelos contra CPU':'Nine fights against the CPU','Ninguno':'None','Mando detectado':'Controller detected','Sin mando: conecta uno para jugar':'No controller detected','B confirma en mando · Esc vuelve':'B confirms · Esc goes back','← / → elige · ↑ / ↓ navega · Esc vuelve':'← / → choose · ↑ / ↓ move · Esc back','El mando controla solo al jugador elegido · el otro jugador sigue con su teclado':'The controller drives its assigned player; the other uses the keyboard','Dificultad de historia':'Story difficulty','DAÑO RECIBIDO':'DAMAGE TAKEN','Puntos cima: ':'Hill points: ','Puntuación: ':'Score: ','Daño recibido: ':'Damage taken: ','Racha: ':'Streak: ','Fragmento ':'Shard ',' de 9 recuperado.':' of 9 recovered.','¡YA!':'FIGHT!','¡Gana J':'PLAYER ',' con ':' wins with ','Toma mi fragmento.':'Take my shard.',' sigue adelante.':' Keep going.','Cumbre':'Summit','Tres islas':'Three Islands','Volcán':'Volcano','Nubes':'Clouds','Ciudad neón':'Neon City','Desierto':'Desert','Espacio':'Space','Templo en ruinas':'Ruined Temple','Aurora glaciar':'Glacial Aurora','Bosque encantado':'Enchanted Forest','Mar de cristal':'Crystal Sea','Pantano tóxico':'Toxic Swamp','Fortaleza de acero':'Steel Fortress','Santuario del Alba':'Dawn Shrine','Fuego':'Fire','Rayo':'Lightning','Roca':'Rock','Hielo':'Ice','Sombra':'Shadow','Selva':'Jungle','Viento':'Wind','Astro':'Astro','Vacío':'Void','Agua':'Water','Veneno':'Poison','Acero':'Steel','Luz':'Light','Equilibrado · fuego y explosiones':'Balanced · fire and blasts','Veloz y ligero · electricidad':'Fast and nimble · electricity','Lento y pesado · golpes brutales':'Slow and heavy · brutal hits','Control · congela al rival':'Control · freezes rivals','Sigiloso · teletransportes':'Stealth · teleportation','Resistente · se cura':'Tough · self-healing','Ultraligero · empuja y atrae':'Ultra-light · push and pull','Técnico · shuriken y cortes':'Technical · shuriken and slashes','Cósmico · orbes y cometas':'Cosmic · orbs and comets','Fluido · olas y embestidas':'Fluid · waves and charges','Sucio · envenena con el tiempo':'Dirty fighter · poison damage','Blindado · cortes perforantes':'Armored · piercing strikes','Radiante · curación y rayos':'Radiant · healing and beams'};Object.assign(EN,{'AJUSTES':'SETTINGS','SOLITARIO':'SOLO','MULTIJUGADOR':'MULTIPLAYER','JUGADOR':'PLAYER','J · ':'P · ','ELIGE TU DUELO':'CHOOSE YOUR SIDE','Elige una categoría · ◀ ▶ o A/D · F / K / Enter':'Choose a side · ◀ ▶ or A/D · Enter','— ECLIPSE DE CRISTAL · ¡elige tu modo! —':'— CRYSTAL ECLIPSE · choose your mode —','Mando, sonido y más':'Controller, audio and more','El mando controla solo al jugador elegido · el otro jugador sigue con su teclado':'Controller only drives its assigned player · the other uses the keyboard','Hace mil años, el Cristal del Alba mantenía en equilibrio el fuego, el rayo, el hielo, el viento y la sombra.':'A thousand years ago, the Dawn Crystal kept fire, lightning, ice, wind, and shadow in balance.','Una noche el Cristal estalló en nueve fragmentos. Cada guardián cree que otro lo rompió.':'One night, the Crystal shattered into nine shards. Each guardian believes another broke it.','Ahora el Torneo de la Cumbre decidirá quién reúne los fragmentos… y quién cae al vacío.':'Now the Summit Tournament will decide who gathers the shards… and who falls into the void.','¡El Cristal ardía en mi templo y ahora no está! ¡Me mirarás a la cara!':'The Crystal burned in my temple, and now it is gone! Face me!','Sentí el trueno romperse. ¡Solo tú llegaste antes que yo al cráter!':'I felt the thunder split. You were the only one at the crater before me!','La montaña lo recuerda todo. Y recuerda que pasaste por aquí esa noche.':'The mountain remembers everything. It remembers you were here that night.','Un fragmento cayó en mi glaciar… y alguien dejó huellas calientes.':'A shard fell on my glacier… and someone left warm footprints.','No me ves, pero yo sí te vi. Llevas algo que me pertenece.':'You cannot see me, but I saw you. You carry something that belongs to me.','Las raíces susurran tu nombre. Devuelve el fragmento al bosque.':'The roots whisper your name. Return the shard to the forest.','Todos los vientos apuntan hacia ti. ¿Casualidad?':'Every wind points to you. Coincidence?','Mi maestro dijo: quien sostiene el fragmento, sostiene la culpa.':'My master said: whoever holds the shard carries the blame.','Las estrellas se apagaron una a una. Tú eres la anomalía.':'The stars went dark one by one. You are the anomaly.','Gracias por reunir los fragmentos. Yo los rompí. Con ellos apagaré el mundo.':'Thank you for gathering the shards. I broke them. With them, I will extinguish the world.','Mis llamas se calman. No fuiste tú. Toma mi fragmento.':'My flames are calm. It was not you. Take my shard.','Perdí. Había huellas negras en el cráter, no tuyas. Sigue adelante.':'I lost. There were black footprints at the crater, not yours. Keep going.','Fuerte y justo. Llévate el fragmento; algo extraño se mueve al norte.':'Strong and fair. Take the shard; something strange stirs to the north.','El hielo no miente: el culpable huele a vacío.':'Ice does not lie: the culprit smells of the void.','Entre las sombras vi algo enorme. Un ojo sin luz. Cuidado.':'In the shadows I saw something huge. An eyeless gaze. Be careful.','La selva te acepta. El fragmento late… y algo quiere apagarlo.':'The jungle accepts you. The shard is beating… and something wants to snuff it out.','El viento lo confirma: la fuente está bajo el volcán. Apúrate.':'The wind confirms it: the source lies beneath the volcano. Hurry.','Mil cortes y ninguno acertó. Ahora lo entiendo: el enemigo es otro.':'A thousand cuts, not one found its mark. Now I understand: the enemy is someone else.','Las estrellas vuelven a brillar. Solo queda uno. El Vacío te espera.':'The stars shine again. Only one remains. The Void awaits.','Imposible… la luz ha vuelto…':'Impossible… the light has returned…','El Vacío se disipó y los nueve fragmentos volaron al cielo.':'The Void dissolved, and the nine shards soared into the sky.','El Cristal del Alba brilló de nuevo. Los guardianes dejaron las armas… hasta el próximo torneo.':'The Dawn Crystal shone once more. The guardians laid down their arms… until the next tournament.','FIN. Gracias por jugar.':'THE END. Thanks for playing.','Bola de fuego':'Fireball','Llamarada':'Blaze','Fénix':'Phoenix','Erupción':'Eruption','Burbuja de marea':'Tide bubble','Tabla de espuma':'Foam surf','Géiser':'Geyser','Corriente de fondo':'Undercurrent','Baba corrosiva':'Corrosive glob','Estanque ácido':'Acid pool','Estallido de esporas':'Sporeburst','Espinas tóxicas':'Toxic spikes','Filo perseguidor':'Seeking blade','Ariete blindado':'Armored ram','Ascenso magnético':'Magnetic rise','Yunque sísmico':'Seismic anvil','Rayo prismático':'Prism beam','Espejo solar':'Solar mirror','Alba ascendente':'Rising dawn','Renovación':'Renewal','OPCIONES':'OPTIONS','Online':'Online','Encuentra un rival en línea':'Find an online opponent','Buscando rival...':'Searching for an opponent...','Conectando a la sala...':'Connecting to the room...','Rival: ':'Opponent: ','El rival se desconectó. Buscando otro...':'Opponent disconnected. Searching for another...','No se pudo conectar: ':'Could not connect: ','Las salas online no están disponibles en esta vista.':'Online rooms are unavailable in this view.','La sala empareja automáticamente a dos jugadores.':'The room automatically matches two players.','Esc cancela la búsqueda':'Esc cancels matchmaking','Reconectando...':'Reconnecting...','Conexión cerrada':'Connection closed','Tú':'You','Rival':'Opponent','◀ ▶ para elegir · Enter/F para entrar · ↑ Opciones':'◀ ▶ choose · Enter/F confirm · ↑ Options','← / → elige · ↑ / ↓ navega · Esc vuelve':'← / → choose · ↑ / ↓ move · Esc back','A/D/W/S o flechas para moverte · F, K o Enter para elegir':'A/D/W/S or arrows to move · F, K or Enter to choose','↑/↓ cambia el mapa':'↑/↓ change arena','Elige…':'Choose…','Cada personaje tiene 4 especiales únicos.':'Every fighter has four unique specials.','B selecciona · Esc vuelve':'B selects · Esc goes back','A/D cambia tu luchador · B o Enter confirma · Esc sale':'A/D choose your fighter · B or Enter confirms · Esc exits','TU LUCHADOR · P':'YOUR FIGHTER · P','RIVAL · P':'OPPONENT · P','Elige con A/D y confirma con B o Enter. Esperando al rival…':'Choose with A/D and confirm with B or Enter. Waiting for your rival…'});const EN_PAIRS=Object.entries(EN).sort((a,b)=>b[0].length-a[0].length);function langText(value){let s=String(value);const P_=CFG.lang=='en'?EN_PAIRS:XL[CFG.lang];if(!P_)return s;for(const [from,to] of P_)s=s.replaceAll(from,to);return s}
function syncLanguage(){document.documentElement.lang=CFG.lang=='en'?'en':'es';document.title=CFG.lang=='en'?'Summit Duel':'Cumbre II';const h=document.getElementById('help');if(h)h.textContent=CFG.lang=='en'?'P1: A/D move · W jump · F attack · G special · H final smash   P2: ←/→ move · ↑ jump · K attack · L special · Ñ final smash   Controller: B select/confirm · View back · A jump · X attack · Y special · RB smash':'J1: A/D mover · W saltar · F golpe · G especial · H smash   J2: ←/→ mover · ↑ saltar · K golpe · L especial · Ñ smash   Mando: B seleccionar/confirmar · View volver · A saltar · X golpe · Y especial · RB smash'}
function txt(s,x,y,sz,col,al='center'){s=langText(s);g.font=`bold ${sz}px "Trebuchet MS",sans-serif`;g.fillStyle=col;g.textAlign=al;g.fillText(s,x,y)}
function bg(){
 const gr=g.createLinearGradient(0,0,0,H);gr.addColorStop(0,M.c[0]);gr.addColorStop(1,M.c[1]);
 g.fillStyle=gr;g.fillRect(-20,-20,W+40,H+40);
 g.fillStyle=M.c[2];g.beginPath();g.arc(740,150,50,0,7);g.fill();
 g.fillStyle=M.c[3];g.beginPath();g.moveTo(0,H);g.lineTo(150,300);g.lineTo(330,H);g.lineTo(480,260);g.lineTo(700,H);g.lineTo(840,320);g.lineTo(960,H);g.fill();
 if(DEC[M.n])DEC[M.n]();
 g.fillStyle=M.n=='Volcán'?'rgba(255,140,50,.65)':'rgba(255,255,255,.35)';for(let i=0;i<28;i++){const d=M.n=='Volcán'?-1:1,x=(i*97+T*(10+i%5*6))%W,y=(((i*53+Math.sin(T+i)*20+T*(8+i%3*5)*d)%H)+H)%H;g.beginPath();g.arc(x,y,1+i%3,0,7);g.fill()}
}
function drawMap(){for(const l of PL){
 g.fillStyle=l.t?'#6b4a2e':'#4a3320';rr(l.x,l.y,l.w,l.t?12:40,5);
 g.fillStyle=M.g;rr(l.x,l.y-4,l.w,10,5)}}
const sh=(h,k)=>{const n=parseInt(h.slice(1),16);return`rgb(${(n>>16&255)*k|0},${(n>>8&255)*k|0},${(n&255)*k|0})`};
const tri=(a,b,c,d,e,f,co)=>{g.fillStyle=co;g.beginPath();g.moveTo(a,b);g.lineTo(c,d);g.lineTo(e,f);g.closePath();g.fill()};
const DEC={
'Espacio':()=>{g.fillStyle='#fff';for(let i=0;i<70;i++){g.globalAlpha=.3+.7*Math.abs(Math.sin(T*1.5+i));g.fillRect(i*137%W,i*89%H,i%3?1.5:2.5,i%3?1.5:2.5)}g.globalAlpha=1;g.fillStyle='#6a4cc9';g.beginPath();g.arc(230,170,70,0,7);g.fill();g.strokeStyle='rgba(255,220,160,.7)';g.lineWidth=8;g.beginPath();g.ellipse(230,170,120,26,-.35,0,7);g.stroke()},
'Templo en ruinas':()=>{for(let i=0;i<7;i++){const x=40+i*140,h=200+i%2*60;g.fillStyle='#7a5532';g.fillRect(x,H-h,34,h);g.fillStyle='#9b6f43';g.fillRect(x-6,H-h,46,12)}},
'Aurora glaciar':()=>{for(let i=0;i<3;i++){g.fillStyle=`hsla(${140+i*50},90%,65%,.22)`;g.beginPath();g.moveTo(0,70+i*30);for(let x=0;x<=W;x+=40)g.lineTo(x,70+i*30+Math.sin(x*.01+T+i)*28);g.lineTo(W,140+i*30);g.lineTo(0,140+i*30);g.fill()}},
'Bosque encantado':()=>{for(let i=0;i<9;i++){const x=i*120-20;g.fillStyle='#0f3322';g.fillRect(x+36,H-130,14,130);tri(x,H-90,x+43,H-250+i%3*30,x+86,H-90,'#14402a');tri(x+6,H-150,x+43,H-290+i%3*30,x+80,H-150,'#1b5a38')}g.fillStyle='#f6ff8a';for(let i=0;i<14;i++){g.globalAlpha=.4+.6*Math.abs(Math.sin(T*2+i));g.fillRect((i*83+Math.sin(T+i)*30+W)%W,200+i*17%250,3,3)}g.globalAlpha=1},
'Ciudad neón':()=>{for(let i=0;i<14;i++){const h=110+i*37%150,x=i*70;g.fillStyle='#120d3a';g.fillRect(x,H-h-30,56,h+30);g.fillStyle=i%2?'#ff4fd8':'#38f9ff';for(let j=0;j<h/24|0;j++)if((i*7+j*3+(T*.7|0))%4)g.fillRect(x+10,H-h-20+j*24,8,10)}},
'Mar de cristal':()=>{g.fillStyle='rgba(190,235,255,.25)';for(let k=0;k<3;k++){g.beginPath();g.moveTo(0,H);for(let x=0;x<=W;x+=30)g.lineTo(x,H-70-k*28+Math.sin(x*.013+T*(1+k*.4)+k)*16);g.lineTo(W,H);g.fill()}},
'Pantano tóxico':()=>{g.fillStyle='rgba(182,224,47,.35)';for(let i=0;i<12;i++){g.beginPath();g.arc(60+i*80+Math.sin(T+i)*14,H-((T*30+i*61)%260),3+i%4*2,0,7);g.fill()}g.fillStyle='rgba(106,143,26,.4)';g.fillRect(0,H-50,W,50)},
'Fortaleza de acero':()=>{for(let i=0;i<6;i++){g.fillStyle='#262b38';g.fillRect(i*170,60,60,H);g.fillStyle=(T*2+i|0)%2?'#ffb347':'#4a5568';g.fillRect(i*170+22,110+i*40,16,16)}},
'Santuario del Alba':()=>{for(let i=0;i<9;i++){const x=60+i*105,h=120+i*47%140;g.globalAlpha=.35+.25*Math.sin(T*2+i);tri(x-26,H,x,H-h,x+26,H,i%2?'#ffe3f2':'#c9a3ff')}g.globalAlpha=1},
'Volcán':()=>{const gl=g.createLinearGradient(0,H-120,0,H);gl.addColorStop(0,'rgba(255,90,20,0)');gl.addColorStop(1,'rgba(255,120,30,.55)');g.fillStyle=gl;g.fillRect(0,H-120,W,120)}};
function limb(x1,y1,x2,y2,w,col,b=0){const mx=(x1+x2)/2-(y2-y1)*b*.04,my=(y1+y2)/2+(x2-x1)*b*.04;g.lineCap='round';
 for(const[ww,cc]of[[w+4,'#1a1226'],[w,col]]){g.strokeStyle=cc;g.lineWidth=ww;g.beginPath();g.moveTo(x1,y1);g.quadraticCurveTo(mx,my,x2,y2);g.stroke()}}
const HAT={
Fuego:(x,y,t)=>{const w=Math.sin(t*14)*2;tri(x-7,y-6,x-9,y-18+w,x-2,y-9,'#ff5a1f');tri(x-3,y-8,x+1,y-23-w,x+5,y-8,'#ffb02a');tri(x+3,y-8,x+9,y-16+w,x+8,y-3,'#ff5a1f')},
Rayo:(x,y)=>{tri(x-8,y-4,x-10,y-17,x-2,y-9,'#fff36b');tri(x-2,y-9,x+3,y-22,x+5,y-8,'#fff36b');tri(x+5,y-8,x+12,y-14,x+8,y-2,'#fff36b')},
Roca:(x,y)=>{g.fillStyle='#6d7890';for(const[a,b,r]of[[-5,-9,4],[3,-10,3.5],[8,-6,3]]){g.beginPath();g.arc(x+a,y+b,r,0,7);g.fill()}},
Hielo:(x,y)=>{tri(x-6,y-7,x-5,y-20,x-1,y-8,'#e8fcff');tri(x-2,y-8,x+2,y-24,x+6,y-8,'#bdf3ff');tri(x+4,y-7,x+9,y-17,x+9,y-4,'#e8fcff')},
Sombra:(x,y,t)=>{g.fillStyle='#2a1050';g.beginPath();g.arc(x-1,y,11.5,Math.PI*.95,Math.PI*2.1);g.fill();limb(x-6,y+8,x-18,y+22+Math.sin(t*6)*3,6,'#2a1050')},
Selva:(x,y,t)=>{limb(x,y-8,x+1,y-12,2,'#1d6b30');g.fillStyle='#38c25a';g.beginPath();g.ellipse(x+1,y-16,3.5,7,Math.sin(t*3)*.3,0,7);g.fill()},
Viento:(x,y,t)=>{limb(x-3,y+9,x-16,y+11+Math.sin(t*8)*4,5,'#e8fff9',4)},
Ninja:(x,y,t)=>{g.fillStyle='#d91e3f';g.fillRect(x-10,y-5,20,4);limb(x-10,y-3,x-23,y+2+Math.sin(t*10)*4,3,'#d91e3f',3)},
Astro:(x,y)=>{g.fillStyle='rgba(255,255,255,.18)';g.beginPath();g.arc(x,y,12.5,0,7);g.fill();g.strokeStyle='rgba(225,240,255,.9)';g.lineWidth=2;g.stroke();limb(x-2,y-12,x,y-20,2,'#fff');g.fillStyle='#ff4d6d';g.beginPath();g.arc(x,y-21,2.5,0,7);g.fill()},
Agua:(x,y,t)=>{tri(x-6,y-6,x,y-22+Math.sin(t*5)*2,x+6,y-6,'#7fb8ff');g.fillStyle='#3d8bff';g.beginPath();g.arc(x,y-6,6,0,Math.PI);g.fill()},
Veneno:(x,y,t)=>{g.fillStyle='#7a9a1a';for(const a of[-6,0,6]){g.beginPath();g.arc(x+a,y-10-Math.abs(Math.sin(t*4+a))*4,3,0,7);g.fill()}},
Acero:(x,y)=>{g.fillStyle='#aab3c4';g.beginPath();g.arc(x,y,11,Math.PI,0);g.fill();g.fillStyle='#e8453c';g.fillRect(x-1.5,y-19,3,9)},
Luz:(x,y,t)=>{g.fillStyle='rgba(255,240,150,.25)';g.beginPath();g.arc(x,y,16+Math.sin(t*4)*1.5,0,7);g.fill();g.strokeStyle='#fff3a0';g.lineWidth=3;g.beginPath();g.ellipse(x,y-14,10,3.5,0,0,7);g.stroke()},
Vacío:(x,y)=>{tri(x-8,y-6,x-12,y-20,x-2,y-9,'#120a24');tri(x+2,y-9,x+12,y-20,x+8,y-4,'#120a24')}};
function drawBody(p,ox=0,al=1,s=1){const c=p.c,t=Date.now()/1000,f=p.f,k=c.n=='Roca'?1.45:1,col=c.col,dk=sh(col,.62),air=!p.gr;
 const a=Math.min(1,Math.abs(p.vx)/2.5),sw=Math.sin(p.ph)*9,cs=Math.cos(p.ph),bob=air?0:Math.sin(t*5)*(a<.2?1.3:.4);
 g.save();g.globalAlpha=al;g.translate(p.x+17+ox*f,p.y+27.5+bob);g.scale(s*f,s);
 const lean=p.stun>0?-.45:Math.max(-.3,Math.min(.3,p.vx*f*.035))+(p.dash>0?.35:0);g.rotate(lean);
 if(p.pw>0){g.fillStyle='rgba(255,180,60,.35)';g.beginPath();g.arc(0,-4,34,0,7);g.fill()}
 if(p.poseT>0){const pulse=1+Math.sin(T*18)*.12;g.strokeStyle=c.col;g.globalAlpha=.35;g.lineWidth=3;g.beginPath();g.ellipse(0,0,23*pulse,34*pulse,0,0,7);g.stroke();g.globalAlpha=al}
 let f1x,f1y,f2x,f2y;
 if(p.slam>0){f1x=10;f2x=-10;f1y=f2y=21}
 else if(air){const up=p.vy<0;f1x=up?8:9;f1y=up?12:21;f2x=up?-6:-9;f2y=up?17:21}
 else{f1x=sw*a+4*(1-a);f1y=22-Math.max(0,cs)*5*a;f2x=-sw*a-4*(1-a);f2y=22-Math.max(0,-cs)*5*a}
 let ax=-sw*a*.8+3,ay=-2,bx=sw*a*.8-2,by=-2,hot=0;
 if(air){ay=-18;by=-16;ax=8;bx=-8}
 if(p.dash>0){ax=24;ay=-12;bx=-16;by=-8}
 if(p.slam>0){ax=8;ay=18;bx=-8;by=18}
 if(p.up>0){ax=6;ay=-34;bx=-4;by=-34}
 if(p.poseT>0){if(p.pose=='fountain'||p.pose=='sunrise'||p.pose=='magnetrise'){ax=5;ay=-37;bx=-12;by=-22}else if(p.pose=='anvil'){ax=14;ay=21;bx=-14;by=21}else if(p.pose=='mirror'){ax=24+Math.sin(T*16)*3;ay=-12;bx=-22;by=-8}else if(p.pose=='renewal'){ax=-8;ay=-28;bx=18;by=-27}else if(p.pose=='spores'){ax=12;ay=-30;bx=-15;by=-25}}
 if(p.sc>60){ax=24;ay=-14;bx=19;by=-10;hot=1}
 if(p.act>10){ax=-9;ay=-8}
 else if(p.act>3){hot=1;if(p.ty=='U'){ax=7;ay=-38}else if(p.ty=='D'){ax=8;ay=22}else{ax=27;ay=-14}}
 if(p.stun>0){ax=14+Math.sin(t*25)*6;ay=-30;bx=-14;by=-30+Math.cos(t*25)*6;f1x=12;f2x=-12;f1y=f2y=21}
 limb(0,0,f2x,f2y,8*k,dk,-5);limb(0,-13,bx,by,6*k,dk,3);
 limb(0,0,1,-15,12*k,col);limb(0,-8,0,-8,14*k,dk);
 limb(0,0,f1x,f1y,8*k,col,-5);
 const hx=3,hy=-24;g.fillStyle=col;g.strokeStyle='#1a1226';g.lineWidth=2.5;g.beginPath();g.arc(hx,hy,9.5,0,7);g.fill();g.stroke();
 const hf=HAT[c.n];if(hf)hf(hx,hy,t);
 if(p.stun>0){g.strokeStyle='#111';g.lineWidth=2;g.beginPath();g.moveTo(hx+2,hy-4);g.lineTo(hx+8,hy+2);g.moveTo(hx+8,hy-4);g.lineTo(hx+2,hy+2);g.stroke()}
 else{g.fillStyle=c.n=='Vacío'?'#ff3df2':'#fff';g.beginPath();g.arc(hx+5,hy-1,3.4,0,7);g.fill();g.fillStyle='#111';g.beginPath();g.arc(hx+6.2,hy-1,1.6,0,7);g.fill()}
 limb(0,-13,ax,ay,6*k,col,3);
 if(hot){g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.arc(ax,ay,7,0,7);g.fill()}
 g.restore()}
function drawP(p){if(p.inv>0&&(p.inv>>2)%2)return;p.ph=(p.ph||0)+Math.abs(p.vx)*.11;
 if(p.gr){g.fillStyle='rgba(0,0,0,.28)';g.beginPath();g.ellipse(p.x+17,p.y+p.h+1,16,4,0,0,7);g.fill()}
 if(p.dash>0){drawBody(p,-28,.2);drawBody(p,-14,.35)}
 drawBody(p);if(p.psn>0){g.fillStyle='rgba(150,230,40,.7)';g.beginPath();g.arc(p.x+17+Math.sin(T*9)*10,p.y-(T*40%30),3,0,7);g.fill()}
 g.fillStyle=p.i?'#5ec8ff':'#ff6ea8';tri(p.x+11,p.y-42,p.x+23,p.y-42,p.x+17,p.y-34,g.fillStyle);
 if(p.act>3&&p.act<=10){g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=6;g.lineCap='round';const cx=p.x+17,cy=p.y+26,f=p.f;g.beginPath();
  if(p.ty=='U')g.arc(cx,cy,40,-2.3,-.8);else if(p.ty=='D')g.arc(cx,cy,40,.8,2.3);else g.arc(cx,cy,38,f>0?-1:Math.PI-1,f>0?1:Math.PI+1);g.stroke()}
 if(p.slam>0&&p.slam<=10){g.strokeStyle='#fff';g.lineWidth=5;g.beginPath();g.ellipse(p.x+p.w/2,p.y+p.h,50+(10-p.slam)*3,16,0,0,7);g.stroke()}
}
function hud(){P.forEach((p,i)=>{const x=i?W-230:30;
 g.fillStyle='rgba(10,8,20,.6)';rr(x-10,H-92,210,80,12);
 g.fillStyle='#333';g.fillRect(x,H-20,190,6);g.fillStyle=p.fs>=100?'#fff':'#ffd23c';g.fillRect(x,H-20,190*p.fs/100,6);
 if(p.fs>=100&&(Date.now()>>8)%2)txt('¡SMASH FINAL! ('+lbl(i)+')',x,H-100,15,'#fff','left');
 txt(MD.k=='online'?(i==onlineSlot?'Tú':'Rival')+' · '+p.c.n:p.c.n+' · J'+(i+1),x,H-68,16,'#f1ece4','left');
 txt(p.dmg.toFixed(0)+'%',x,H-28,38,`hsl(${Math.max(0,55-p.dmg*.4)},95%,62%)`,'left');
 if(['points','king'].includes(MD.k))txt((MD.k=='king'?'CIMA ':'PTS ')+Math.floor(MD.k=='king'?p.king/60:p.score),x+188,H-29,13,'#ffd23c','right');
 for(let s=0;s<3;s++){g.fillStyle=s<p.st?p.c.col:'#444';g.beginPath();g.arc(x+130+s*22,H-32,8,0,7);g.fill()}})}
const SEL=[0,1,2,3,4,5,6,7,8,10,11,12,13],rnd=()=>SEL[Math.random()*SEL.length|0];
const BAR=(x,y,l,v,col)=>{txt(l,x,y+9,11,'#c9c1d8','left');g.fillStyle='rgba(255,255,255,.12)';rr(x+52,y,110,10,5);g.fillStyle=col;rr(x+52,y,110*v,10,5)};
function rbw(s,y,z){g.font=`bold ${z}px "Trebuchet MS",sans-serif`;let x=W/2-g.measureText(s).width/2;for(const ch of s){txt(ch,x,y+Math.sin(T*3+x*.02)*4,z,`hsl(${(T*60+x*.3)%360},90%,66%)`,'left');x+=g.measureText(ch).width}}
function drawSel(){bg();const bm=Math.sin(T*2)*14;
 for(let i=0;i<2;i++){const c=CH[sel[i]],d=i?-1:1,x0=i?W:0,cx=i?810:150,r=rdy[i];
  g.globalAlpha=.3;g.fillStyle=c.col;g.beginPath();g.moveTo(x0,0);g.lineTo(x0+d*(340+bm),0);g.lineTo(x0+d*(230-bm),H);g.lineTo(x0,H);g.fill();g.globalAlpha=1;
  txt(MD.k=='online'?(i==onlineSlot?'TU LUCHADOR · P':'RIVAL · P')+(i+1):i&&BOT[1]?'CPU':'JUGADOR '+(i+1),cx,122,18,i?'#5ec8ff':'#ff6ea8');
  g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.ellipse(cx,334,70,12,0,0,7);g.fill();
  drawBody({x:cx-17,y:237-(r?Math.abs(Math.sin(T*3))*10:0),w:34,h:50,f:i?-1:1,vx:r?0:3,vy:0,gr:1,act:r&&(T*2)%1<.3?8:0,stun:0,dash:0,slam:0,up:0,sc:0,c,ph:T*9},0,1,3);
  txt(c.n.toUpperCase(),cx,372,38,c.col);txt(c.d,cx,392,13,'#f1ece4');
  [['VEL',c.sp/6],['SALTO',c.jp/14],['FUERZA',c.ad/12]].forEach((q,j)=>BAR(cx-81,402+j*16,q[0],q[1],c.col));
  const m=c.m.split(' · ');txt(m[0]+' · '+m[1],cx,468,11,'#c9c1d8');txt(m[2]+' · '+m[3],cx,482,11,'#c9c1d8');
  txt('★ '+c.fn,cx,500,13,'#ffd23c');txt(r?'¡LISTO!':'Elige…',cx,524,18,r?'#6fcf6a':'#aaa')}
 rbw('DUELO EN LA CUMBRE II',56,44);txt('ECLIPSE DE CRISTAL',W/2,86,16,'#ffd23c');txt(MD.k=='online'?'A/D cambia tu luchador · B o Enter confirma · Esc sale':'J1 '+ctl(0)+' · J2 '+ctl(1)+' · elegir y confirmar',W/2,112,12,'#f1ece4');
 SEL.forEach((x,j)=>{const c=CH[x],cx=322+(j==12?1:j%3)*108,cy=130+(j/3|0)*64,on=sel[0]==x||sel[1]==x;
  g.fillStyle='rgba(10,8,20,.72)';rr(cx,cy,104,58,10);
  for(let i=0;i<2;i++)if(sel[i]==x){g.strokeStyle=rdy[i]?'#6fcf6a':i?'#5ec8ff':'#ff6ea8';g.lineWidth=3;g.beginPath();g.roundRect(cx+i*3,cy+i*3,104-i*6,58-i*6,10);g.stroke()}
  drawBody({x:cx-6,y:cy+2,w:34,h:50,f:1,vx:on?3:0,vy:0,gr:1,act:0,stun:0,dash:0,slam:0,up:0,sc:0,c,ph:on?T*10:0},0,1,.55);txt(c.n,cx+68,cy+34,13,'#fff')});
 if(MD.k=='online'){txt('Elige con A/D y confirma con B o Enter. Esperando al rival…',W/2,514,14,'#f1ece4');return}const gr=g.createLinearGradient(380,0,580,0);M.c.forEach((c,i)=>gr.addColorStop(i/3,c));g.fillStyle=gr;rr(380,492,200,8,4);
 txt('◀ '+M.n+' ▶',W/2,486,17,'#fff');txt('↑/↓ cambia el mapa',W/2,518,12,'#c9c1d8')}
function selInput(){if(MD.k=='online'){onlineSelectIn();return}for(let i=0;i<2;i++){const k=C[i];if(i&&BOT[1])continue;
 if(!rdy[i]){const d=(J[k.r]?1:0)-(J[k.l]?1:0);if(d){sel[i]=SEL[(SEL.indexOf(sel[i])+d+SEL.length)%SEL.length];sfx('sel')}}
 if(J[k.u]||J[k.d]){mapI=(mapI+(J[k.d]?1:MAPS.length-1))%MAPS.length;M=MAPS[mapI];sfx('mv')}
 if(J[k.a]){rdy[i]=!rdy[i];sfx(rdy[i]?'rd':'mv')}}
 if(rdy[0]&&rdy[1])go()}
function fsGo(p,o){sfx('sm');p.fs=0;p.inv=220;fs={t:45,p};const c=p.c.n;
 if(c=='Fuego')for(let i=0;i<10;i++)HZ.push({x:i%3?80+Math.random()*780:o.x-25,y:0,w:80,h:H,t:35+i*9,life:14,dmg:16,kb:15,col:'#ff7a2a'});
 else if(c=='Rayo')for(let i=0;i<7;i++)HZ.push({x:o.x-30+(i%2?1:-1)*i*45,y:0,w:60,h:H,t:35+i*14,life:10,dmg:18,kb:16,col:'#fff36b'});
 else if(c=='Viento')for(const s of[-1,1])for(let j=0;j<2;j++)HZ.push({x:s>0?-100-j*220:W+10+j*220,y:0,w:90,h:H,t:40,life:130,vx:s*10,dmg:10,kb:13,col:'#b8f2e6'});
 else if(c=='Ninja')for(let i=0;i<14;i++)HZ.push({x:i*70,y:0,w:40,h:H,t:35+i*5,life:5,dmg:9,kb:10,col:'#ff4d6d'});
 else if(c=='Astro')for(const s of[-1,1])HZ.push({x:W/2-100+s*10,y:0,w:200,h:H,t:40,life:55,vx:s*9,dmg:20,kb:19,col:'#ff9ee5'});
 else if(c=='Vacío')for(let i=0;i<12;i++)HZ.push({x:Math.random()*880,y:0,w:90,h:H,t:30+i*7,life:14,dmg:18,kb:17,col:'#2a1a4a'});
 else if(c=='Hielo')HZ.push({x:0,y:H-200,w:W,h:200,t:50,life:25,dmg:22,kb:17,col:'#bdf3ff'});
 else if(c=='Sombra')for(let i=0;i<8;i++)HZ.push({x:o.x-140+i*40,y:o.y-60,w:50,h:170,t:30+i*8,life:6,dmg:12,kb:12,col:'#b07cff'});
 else if(c=='Selva')for(let i=0;i<9;i++)HZ.push({x:i*107,y:100,w:100,h:H-100,t:35+i*8,life:14,dmg:15,kb:15,col:'#4fd36a'});
 else if(c=='Agua')for(const s of[-1,1])for(let j=0;j<3;j++)HZ.push({x:s>0?-120-j*200:W+20+j*200,y:H-260,w:110,h:260,t:40,life:130,vx:s*9,dmg:14,kb:15,col:'#3d8bff'});
 else if(c=='Veneno')for(let i=0;i<12;i++)HZ.push({x:i*80,y:H-160,w:70,h:160,t:30+i*6,life:40,dmg:13,kb:12,col:'#b6e02f'});
 else if(c=='Acero')for(let i=0;i<16;i++)HZ.push({x:Math.random()*900,y:0,w:36,h:H,t:30+i*5,life:6,dmg:11,kb:11,col:'#d9dde6'});
 else if(c=='Luz'){HZ.push({x:o.x-60,y:0,w:120,h:H,t:50,life:40,dmg:24,kb:20,col:'#fff6c9'});for(const s of[-1,1])HZ.push({x:W/2,y:0,w:70,h:H,t:60,life:80,vx:s*8,dmg:14,kb:14,col:'#fff6c9'})}
 else for(const s of[-1,1])HZ.push({x:p.x+(s>0?p.w:-60),y:190,w:60,h:350,t:40,life:75,vx:s*12,dmg:20,kb:18,col:'#b9a27a'})}
function drawHZ(){for(const h of HZ){if(h.t>0){g.fillStyle='rgba(255,60,60,.22)'}else{g.fillStyle=h.col;g.globalAlpha=.85}
 g.fillRect(h.x,h.y,h.w,h.h);g.globalAlpha=1}}
function drawFX(){for(const f of FX){g.globalAlpha=Math.min(1,f.life/12);g.fillStyle=f.col;g.beginPath();g.arc(f.x,f.y,f.r*Math.min(1,f.life/7),0,7);g.fill()}g.globalAlpha=1}
function drawProjectile(b){const q=b.q,r=q.r||8,k=q.kind;g.save();g.translate(b.x,b.y);g.rotate(Math.atan2(b.vy,b.vx));g.shadowColor=q.col||'#fff';g.shadowBlur=k==='pool'?8:14;g.fillStyle=q.col||'#fff';g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=2;
 if(k==='bubble'){g.beginPath();g.ellipse(0,0,r*.8,r,0,0,7);g.fill();g.fillStyle='rgba(255,255,255,.8)';g.beginPath();g.arc(-r*.25,-r*.35,Math.max(2,r*.2),0,7);g.fill()}
 else if(k==='pool'){g.beginPath();g.ellipse(0,0,r*1.5,7,0,0,7);g.fill();g.stroke()}
 else if(k==='blade'){g.beginPath();g.moveTo(-r,-r*.35);g.lineTo(r*1.8,0);g.lineTo(-r,r*.35);g.closePath();g.fill();g.stroke()}
 else if(k==='prism'||k==='sunray'){g.beginPath();g.moveTo(-r,0);g.lineTo(0,-r);g.lineTo(r*1.5,0);g.lineTo(0,r);g.closePath();g.fill();g.stroke()}
 else if(k==='wave'){g.beginPath();g.moveTo(-r,-r*.2);g.quadraticCurveTo(-r*.4,-r*1.5,0,-r*.2);g.quadraticCurveTo(r*.5,r*.9,r,0);g.lineTo(r,r*.55);g.lineTo(-r,r*.55);g.closePath();g.fill()}
 else if(k==='toxic-spike'){g.beginPath();g.moveTo(-r*.7,r);g.lineTo(0,-r*1.4);g.lineTo(r*.7,r);g.closePath();g.fill()}
 else if(k==='mote'){g.beginPath();g.arc(0,0,r,0,7);g.fill();g.stroke()}
 else {g.beginPath();g.arc(0,0,r,0,7);g.fill();g.fillStyle='#fff';g.beginPath();g.arc(-r*.2,-r*.2,Math.max(2,r/2.2),0,7);g.fill()}g.restore()}
const ITD=[{e:'❤',c:'#ff6b81'},{e:'★',c:'#e6b800'},{e:'⚡',c:'#ff8a00'},{e:'👟',c:'#2fa8d8'},{e:'💣',c:'#444'},{e:'✦',c:'#9a5cff'},{e:'❄',c:'#2fa8d8'},{e:'☠',c:'#6b8f1a'},{e:'🌀',c:'#7a4cff'},{e:'🎲',c:'#d4af37'}];
function pick(p,it){const t=it.t;sfx(t==4?'bomb':t>5?'mag':'it');const o=P[1-p.i];
 if(t==0)p.dmg=Math.max(0,p.dmg-25);else if(t==1)p.inv=Math.max(p.inv,300);else if(t==2)p.pw=600;else if(t==3)p.buf=400;
 else if(t==4){shake=12;for(const q of P)if(Math.hypot(q.x-it.x,q.y-it.y)<120){A=null;hit(q,12,11,Math.sign(q.x-it.x)||1)}}
 else if(t==5)p.fs=Math.min(100,p.fs+50);
 else if(t==6){o.stun=Math.max(o.stun,70);o.vx=0}
 else if(t==7)o.psn=360;
 else if(t==8){const x=p.x,y=p.y;p.x=o.x;p.y=o.y;o.x=x;o.y=y;p.inv=Math.max(p.inv,30)}
 else pick(p,{t:Math.random()*9|0,x:it.x,y:it.y})}
function itemStep(){if(--itT<=0){itT=MD.it;if(MD.k!='online'&&CFG.items&&IS.length<(MD.it<200?5:2)){const l=PL[Math.random()*PL.length|0];IS.push({x:l.x+20+Math.random()*(l.w-40),y:-20,vy:0,t:Math.random()*10|0,l:1100})}}
 for(const it of IS){it.l--;it.vy=Math.min(it.vy+.4,7);const py=it.y+24;it.y+=it.vy;
  if(it.vy>=0)for(const l of PL)if(it.x>l.x&&it.x<l.x+l.w&&py<=l.y+2&&it.y+24>=l.y){it.y=l.y-24;it.vy=0}
  for(const p of P)if(it.l>0&&ov({x:it.x-12,y:it.y,w:24,h:24},p)){pick(p,it);it.l=0}}
 IS=IS.filter(it=>it.l>0&&it.y<H+40)}
function drawIT(){for(const it of IS){if(it.l<200&&(it.l>>3)%2)continue;const d=ITD[it.t];g.fillStyle=d.c;rr(it.x-12,it.y,24,24,6);txt(d.e,it.x,it.y+19,16,'#fff')}}
const LORE=[['Narrador','Hace mil años, el Cristal del Alba mantenía en equilibrio el fuego, el rayo, el hielo, el viento y la sombra.'],['Narrador','Una noche el Cristal estalló en nueve fragmentos. Cada guardián cree que otro lo rompió.'],['Narrador','Ahora el Torneo de la Cumbre decidirá quién reúne los fragmentos… y quién cae al vacío.']];
const DI=['¡El Cristal ardía en mi templo y ahora no está! ¡Me mirarás a la cara!','Sentí el trueno romperse. ¡Solo tú llegaste antes que yo al cráter!','La montaña lo recuerda todo. Y recuerda que pasaste por aquí esa noche.','Un fragmento cayó en mi glaciar… y alguien dejó huellas calientes.','No me ves, pero yo sí te vi. Llevas algo que me pertenece.','Las raíces susurran tu nombre. Devuelve el fragmento al bosque.','Todos los vientos apuntan hacia ti. ¿Casualidad?','Mi maestro dijo: quien sostiene el fragmento, sostiene la culpa.','Las estrellas se apagaron una a una. Tú eres la anomalía.','Gracias por reunir los fragmentos. Yo los rompí. Con ellos apagaré el mundo.'];
const DW=['Mis llamas se calman. No fuiste tú. Toma mi fragmento.','Perdí. Había huellas negras en el cráter, no tuyas. Sigue adelante.','Fuerte y justo. Llévate el fragmento; algo extraño se mueve al norte.','El hielo no miente: el culpable huele a vacío.','Entre las sombras vi algo enorme. Un ojo sin luz. Cuidado.','La selva te acepta. El fragmento late… y algo quiere apagarlo.','El viento lo confirma: la fuente está bajo el volcán. Apúrate.','Mil cortes y ninguno acertó. Ahora lo entiendo: el enemigo es otro.','Las estrellas vuelven a brillar. Solo queda uno. El Vacío te espera.','Imposible… la luz ha vuelto…'];
const EPI=[['Narrador','El Vacío se disipó y los nueve fragmentos volaron al cielo.','#ffd23c'],['Narrador','El Cristal del Alba brilló de nuevo. Los guardianes dejaron las armas… hasta el próximo torneo.','#ffd23c'],['Narrador','FIN. Gracias por jugar.','#ffd23c']];
LORE.forEach(l=>l.push('#ffd23c'));
const abox=p=>p.ty=='U'?{x:p.x-6,y:p.y-38,w:p.w+12,h:44}:p.ty=='D'?{x:p.x-2,y:p.y+p.h-4,w:p.w+4,h:36}:{x:p.f>0?p.x+p.w:p.x-34,y:p.y+4,w:34,h:42};
function say(l,cb){dl=l;di=0;dc=0;dn=cb;scr='dlg'}
function dlgIn(){const t=langText(dl[di][1]);if(dc<t.length)dc+=.8;
 if(J.Enter||J.KeyF||J.KeyK||J.Space){if(dc<t.length)dc=t.length;else if(++di>=dl.length){const f=dn;dn=null;f&&f()}else dc=0}}
const ROOT=[['🎮','Solitario','J1 contra CPU'],['👥','Multijugador','P1 contra P2']];
const SOLO=[
 {icon:'⛰️',name:'Historia',desc:'Nueve duelos contra CPU',k:'st',bot:1,st:3,it:380,story:1},
 {icon:'🤖',name:'Duelo CPU',desc:'Un combate contra la máquina',k:'cpu',bot:1,st:3,it:380},
 {icon:'🔥',name:'Supervivencia',desc:'Rachas contra CPUs cada vez peores',k:'sv',bot:1,st:3,it:300},
 {icon:'🎯',name:'Entrenamiento',desc:'Práctica sin límite de vidas',k:'tr',bot:0,st:99,it:380},
 {icon:'⏱️',name:'Contrarreloj',desc:'Supera a la CPU en 90 segundos',k:'timer',bot:1,st:3,it:240,limit:5400}
];
const DUO=[
 {icon:'⚔️',name:'Versus',desc:'Combate clásico a tres vidas',k:'vs',bot:0,st:3,it:380},
 {icon:'💀',name:'Muerte súbita',desc:'Una sola vida',k:'sd',bot:0,st:1,it:380},
 {icon:'🌀',name:'Caos total',desc:'Gravedad lunar y objetos',k:'ch',bot:0,st:3,g:.55,it:70},
 {icon:'🏆',name:'Carrera de puntos',desc:'Gana quien más daño inflija',k:'points',bot:0,st:3,it:300,limit:4800},
 {icon:'👑',name:'Rey de la cumbre',desc:'Controla el centro de la arena',k:'king',bot:0,st:3,it:300,limit:5400},
 {icon:'💎',name:'Caza de objetos',desc:'Lluvia constante de objetos',k:'loot',bot:0,st:3,it:75},
 {icon:'🌐',name:'Online',desc:'Encuentra un rival en línea',k:'online',bot:0,st:3,it:99999}
];
function chooseGroup(i){menuTarget=i==0?'solo':'multi';menuPunch=34;menuPage='transition';sfx('sp')}
function onlineSend(data){if(!onlineSocket||!onlineMatchId)return;try{onlineSocket.send({...data,matchId:onlineMatchId})}catch(e){}}
function startOnlineFight(msg){onlineSlot=msg.slot;onlineMatchId=msg.matchId;onlineMessage='Rival: '+(msg.opponent||'Fighter');onlineResultSent=false;lastOnlineState=0;onlineActive=true;onlineStarted=false;onlineReady=[false,false];BOT=[0,0];sty=null;sel=[0,2];rdy=[0,0];mapI=0;MD={k:'online',st:3,g:1,it:99999,limit:0};LV=1;scr='sel';onlineSend({type:'selection',character:sel[onlineSlot],ready:false})}
function beginOnlineFight(){if(onlineStarted||!onlineReady[0]||!onlineReady[1])return;onlineStarted=true;for(const code of [...Object.values(KB1),...Object.values(KB2)]){K[code]=0;J[code]=0}mapI=0;M=MAPS[mapI];PL=M.p;start()}
function onlineSelectIn(){const i=onlineSlot,k=KB1;if(onlineReady[i])return;const d=(J[k.r]?1:0)-(J[k.l]?1:0);if(d){const at=SEL.indexOf(sel[i]),next=SEL[(at+(d>0?1:SEL.length-1))%SEL.length];if(next!=sel[i]){sel[i]=next;sfx('sel');onlineSend({type:'selection',character:next,ready:false})}}if(J[k.a]||J.Enter){onlineReady[i]=true;rdy[i]=1;onlineSend({type:'selection',character:sel[i],ready:true});sfx('rd');beginOnlineFight()}}
function applyOnlineMessage(raw){let msg;try{msg=JSON.parse(raw.data)}catch(e){return}if(msg.type=='waiting'){onlineMessage='Buscando rival...';return}if(msg.type=='matched'){startOnlineFight(msg);return}if(msg.type=='selection'&&scr=='sel'&&onlineActive&&Number.isInteger(msg.character)&&msg.character>=0&&msg.character<CH.length){const i=1-onlineSlot;sel[i]=msg.character;onlineReady[i]=!!msg.ready;rdy[i]=onlineReady[i]?1:0;beginOnlineFight();return}if(msg.type=='input'&&onlineActive&&scr=='fight'){const code=KB2[msg.key];if(!code)return;if(msg.down&&!K[code])J[code]=1;K[code]=!!msg.down;return}if(msg.type=='state'&&onlineActive&&onlineSlot==1&&msg.state&&Array.isArray(msg.state.players)&&msg.state.players.length==2){const fields=['x','y','vx','vy','f','dmg','fs','st','stun','inv','gr','jm','cd','sc','up','uu','buf','pw','psn','armor','act','ty','tp','dash','dq','slam','sq','drop','pose','poseT','score','king','hd'];msg.state.players.forEach((v,i)=>{if(!v||!Number.isFinite(v.x)||!Number.isFinite(v.y))return;for(const key of fields)if(v[key]!==undefined)P[i][key]=v[key];P[i].on=PL[v.onIndex]||null});B=(msg.state.bullets||[]).map(b=>({...b,o:P[b.owner]}));HZ=msg.state.hazards||[];return}if(msg.type=='result'&&onlineActive){scr='end';win=P[msg.winner];return}if(msg.type=='opponentLeft'){onlineActive=false;onlineMatchId=null;for(const code of Object.values(KB2)){K[code]=0;J[code]=0}B=[];HZ=[];onlineMessage='El rival se desconectó. Buscando otro...';scr='onlineWait'}}
function joinWsRoom(){return new Promise((res,rej)=>{
 const q=new URLSearchParams(location.search).get('ws'),proto=location.protocol=='https:'?'wss:':'ws:';
 if(!q&&!/^https?:$/.test(location.protocol))return rej(new Error('Abre el juego con: node online-server.js'));
 let ws;try{ws=new WebSocket(q||proto+'//'+location.host+'/ws')}catch(e){return rej(new Error('Dirección del servidor no válida'))}
 const s={onmessage:null,onclose:null,onreconnect:null,q:[],send:d=>{if(ws.readyState==1)ws.send(JSON.stringify(d))},close:()=>{try{ws.close()}catch(e){}}};
 let opened=false;const t=setTimeout(()=>{if(!opened){try{ws.close()}catch(e){}rej(new Error('El servidor no responde'))}},8000);
 ws.onopen=()=>{opened=true;clearTimeout(t);res(s)};
 ws.onmessage=e=>{if(s.onmessage)s.onmessage(e);else s.q.push(e)};
 ws.onclose=e=>{clearTimeout(t);if(!opened)rej(new Error('No se pudo conectar al servidor'));else if(s.onclose)s.onclose({reason:e.reason||'Conexión cerrada'})};
 Object.defineProperty(s,'onmessage',{set(f){this._m=f;if(f){const b=this.q.splice(0);b.forEach(f)}},get(){return this._m}});
})}
async function connectOnline(){const attempt=++onlineAttempt;onlineMessage='Conectando a la sala...';scr='onlineWait';try{const socket=typeof WebsimSocket!='undefined'?await WebsimSocket.joinRoom():await joinWsRoom();if(attempt!=onlineAttempt){socket.close();return}onlineSocket=socket;socket.onmessage=applyOnlineMessage;socket.onreconnect=()=>{onlineActive=false;onlineMatchId=null;onlineMessage='Reconectando...';scr='onlineWait'};socket.onclose=e=>{if(onlineSocket===socket){onlineSocket=null;onlineActive=false;onlineMessage=e.reason||'Conexión cerrada';if(scr!='menu')scr='onlineWait'}}}catch(e){onlineMessage='No se pudo conectar: '+(e?.message||'inténtalo de nuevo')}}
function leaveOnline(){onlineAttempt++;onlineActive=false;onlineMatchId=null;if(onlineSocket){const s=onlineSocket;onlineSocket=null;try{s.close()}catch(e){}}}
function chooseMode(i){const list=menuPage=='solo'?SOLO:DUO;if(i>=list.length){menuPage='root';mi=0;menuAnim=0;sfx('ok');return}const m=list[i];BOT=[0,m.bot];applyCfg();sty=m.story?{ch:0,ord:[]}:null;MD={k:m.k,st:m.st,g:m.g||1,it:m.it,limit:m.limit||0};LV=m.k=='sv'?1.2:2;SV=0;rdy=[0,m.bot];if(m.bot)sel[1]=rnd();sfx('ok');if(m.k=='online'){connectOnline();return}scr='sel'}
function menuIn(){const enter=J.KeyF||J.KeyK||J.Enter,old=mi;if(menuPage=='transition'){if(--menuPunch<=0){menuPage=menuTarget;mi=0;menuAnim=30}return}if(menuAnim>0)menuAnim--;if(J.Escape&&menuPage!='root'){menuPage='root';mi=0;menuAnim=0;sfx('ok');return}
 if(menuPage=='root'){if(J.KeyW||J.ArrowUp){scr='set';sfx('ok');return}if(J.KeyA||J.ArrowLeft)mi=0;if(J.KeyD||J.ArrowRight)mi=1;if(mi!=old)sfx('mv');if(enter||J.KeyS||J.ArrowDown){chooseGroup(mi)}return}
 const list=menuPage=='solo'?SOLO:DUO,n=list.length+1;if(J.KeyA||J.ArrowLeft){if(mi%2)mi--}if(J.KeyD||J.ArrowRight){if(mi%2==0&&mi+1<n)mi++}if(J.KeyW||J.ArrowUp){if(mi>=2)mi-=2;else if(mi>0)mi=0}if(J.KeyS||J.ArrowDown){if(mi+2<n)mi+=2;else mi=n-1}if(mi!=old)sfx('mv');if(enter)chooseMode(mi)}
function go(){if(sty){sty.ch=0;sty.ord=[0,1,2,3,4,5,6,7,8].filter(x=>x!=sel[0]).slice(0,8).concat(9);say(LORE,()=>chap())}else start()}
function chap(){const i=sty.ch,x=sty.ord[i],r=CH[x],h=CH[sel[0]];sel[1]=x;mapI=x==9?2:i%MAPS.length;M=MAPS[mapI];PL=M.p;LV=(x==9?2.6:1+i*.3)*[.65,1,1.3,1.6][CFG.difficulty??1];
 say([[r.n,DI[x],r.col],[h.n,x==9?'¡Entonces todo era tu plan! Esto termina aquí.':'¡Yo no rompí el Cristal! Pero si hace falta pelear, pelearé.',h.col]],()=>{BOT=[0,1];start()})}
function endNext(){
 if(MD.k=='online'){leaveOnline();scr='menu';menuPage='multi';mi=6;return}
 if(MD.k=='sv'){if(win.i==0){SV++;X.sv(SV);LV+=.3;sel[1]=rnd();mapI=Math.random()*MAPS.length|0;start()}else{scr='menu';BOT=[0,0]}return}
 if(!sty){scr='sel';rdy=[0,BOT[1]?1:0];return}
 const i=sty.ch,x=sty.ord[i],r=CH[x];
 if(win.i!=0){start();return}
 if(i>=sty.ord.length-1)say([[r.n,DW[x],r.col],...EPI],()=>{X.story();sty=null;BOT=[0,0];scr='menu'});
 else say([[r.n,DW[x],r.col],['Narrador','Fragmento '+(i+1)+' de 9 recuperado.','#ffd23c']],()=>{sty.ch++;chap()})}
function ai(p,o){const k=C[p.i],r=Math.random,L=LV;
 for(const x in k)K[k[x]]=0;if(MD.k=='tr')return;
 const dx=o.x-p.x,ad=Math.abs(dx),dy=o.y-p.y,cx=p.x+p.w/2,mn=Math.min(...PL.map(l=>l.x)),mx=Math.max(...PL.map(l=>l.x+l.w));
 const mv=d=>{K[d>0?k.r:k.l]=1};
 if(p.fs>=100)J[k.f]=1;
 if(p.stun>0)return;
 if(cx<mn||cx>mx||(p.y>H-140&&!p.gr)){mv(W/2-cx);
  if(p.vy>0&&r()<.15&&p.jm<2)J[k.u]=1;
  if(p.vy>2&&!p.uu&&p.jm>=2){K[k.u]=1;J[k.s]=1}
  return}
 const it=IS[0],tx=it&&ad>140&&L>1.2?it.x:o.x;
 if(Math.abs(tx-cx)>(tx==o.x?50:8))mv(tx-cx);else p.f=Math.sign(dx)||1;
 if(ad<60&&Math.abs(dy)<50&&r()<.07*L){J[k.a]=1;if(dy<-30)K[k.u]=1}
 else if(ad<260&&Math.abs(dy)<60&&r()<.012*L){if(ad<110&&r()<.4)K[k.d]=1;else if(ad<=150)mv(dx);J[k.s]=1}
 if(dy<-70&&r()<.04*L&&p.jm<2)J[k.u]=1;
 if(p.gr&&r()<.004*L)J[k.u]=1}
function drawMenu(){bg();
 g.fillStyle='rgba(9,7,21,.44)';rr(28,18,904,54,18);
 const title='DUELO EN LA CUMBRE II';g.font='bold 35px "Trebuchet MS",sans-serif';g.shadowColor='#25103d';g.shadowBlur=14;txt(title,W/2,56,35,'#f8eaff');g.shadowBlur=0;
 g.fillStyle='rgba(255,211,80,.16)';rr(818,27,98,36,12);g.strokeStyle='rgba(255,225,129,.65)';g.lineWidth=1.5;g.beginPath();g.roundRect(818,27,98,36,12);g.stroke();txt('⚙ OPCIONES',867,51,13,'#ffe38b');
 if(menuPage=='root'||menuPage=='transition'){const trans=menuPage=='transition',progress=trans?1-menuPunch/34:0;
  txt(trans?'¡A LUCHAR!':'ELIGE TU DUELO',W/2,119,19,trans?'#fff':'#ffd66e');
  for(let i=0;i<2;i++){const on=i==mi,base=i?720:240,side=i?1:-1,col=i?'#66d9ff':'#ff719f';g.fillStyle=on?'rgba(255,255,255,.055)':'rgba(5,4,18,.25)';rr(i?505:55,153,400,322,24);g.strokeStyle=on?col:'rgba(255,255,255,.12)';g.lineWidth=on?2.5:1;g.beginPath();g.roundRect(i?55+450:55,153,400,322,24);g.stroke();
   const character=CH[i?7:0],startX=base,attacks=trans&&i==(menuTarget=='multi'?1:0);let px=base,py=218+Math.sin(T*3+i)*4,act=(T*1.2+i*.6)%1<.14?7:0,vx=Math.sin(T*3+i)*2.2,alpha=1;
   if(trans){if(attacks){px+=-side*progress*178;act=progress>.18&&progress<.8?6:0;vx=-side*6}else{px+=side*progress*178;py+=progress*progress*84;act=0;vx=side*8;alpha=Math.max(.25,1-progress*.55)}}
   const guy={x:px-34,y:py,w:34,h:50,f:i?-1:1,vx,vy:0,gr:1,act,ty:'F',stun:0,dash:0,slam:0,up:0,sc:0,c:character,ph:T*8,pw:on?18:0,poseT:0};drawBody(guy,0,alpha,2.45);
   g.fillStyle=col;g.globalAlpha=.14+Math.sin(T*2+i)*.04;g.beginPath();g.ellipse(base,349,145,12,0,0,7);g.fill();g.globalAlpha=1;
   txt(ROOT[i][0],base,391,19,on?col:'#aaa');txt(ROOT[i][1].toUpperCase(),base,425,27,on?'#fff':'#ded9e8');txt(ROOT[i][2],base,451,14,'#c7bfd6');
   if(on&&!trans){g.strokeStyle=col;g.globalAlpha=.7+Math.sin(T*6)*.2;g.lineWidth=2;g.beginPath();g.arc(base,275,86+Math.sin(T*3)*4,0,7);g.stroke();g.globalAlpha=1}}
  if(trans&&progress>.36&&progress<.8){const x=menuTarget=='solo'?450:510;g.strokeStyle='#fff1a6';g.lineWidth=4;g.globalAlpha=.8;g.beginPath();g.arc(x,270,20+(progress-.36)*60,0,7);g.stroke();g.globalAlpha=1}
  txt('◀ ▶ para elegir · Enter/F para entrar · ↑ Opciones',W/2,515,14,'#e3dced');return}
 const list=menuPage=='solo'?SOLO:DUO;txt(menuPage=='solo'?'SOLITARIO · J1 VS CPU':'MULTIJUGADOR · P1 VS P2',W/2,113,22,'#fff');
 const rows=Math.ceil((list.length+1)/2),fly=menuAnim/30*(menuPage=='solo'?-145:145);for(let i=0;i<list.length+1;i++){const back=i==list.length,m=back?{icon:'↩',name:'Volver',desc:'Elegir otra categoría'}:list[i],on=i==mi,col=i%2,row=i>>1,bx=105+col*390,by=164+row*(314/rows),h=Math.min(76,286/rows),cy=by+h/2;g.save();g.translate(bx+175+fly,cy+Math.sin(T*3+i)*1.6);g.fillStyle=on?'rgba(174,111,255,.25)':'rgba(10,8,20,.66)';rr(-175,-h/2,350,h-5,14);g.strokeStyle=on?menuPage=='solo'?'#ff719f':'#66d9ff':'rgba(255,255,255,.14)';g.lineWidth=on?2.5:1;g.beginPath();g.roundRect(-175,-h/2,350,h-5,14);g.stroke();txt(m.icon,-144,7,29,'#fff');txt(m.name,-112,-4,18,on?'#ffd66e':'#f1ece4','left');txt(m.desc,-112,18,12,'#c9c1d8','left');g.restore()}
 txt('← / → elige · ↑ / ↓ navega · Esc vuelve',W/2,520,14,'#f1ece4')}
const SO=[['Mando','pad',['Ninguno','Jugador 1','Jugador 2']],['Efectos de sonido','sfx',['No','Sí']],['Música','mus',['No','Sí']],['Volumen','vol'],['Temblor de pantalla','shk',['No','Sí']],['Objetos','items',['No','Sí']],['Idioma','lang',['Español','English','Français','Português']],['Dificultad de historia','difficulty',['Fácil','Normal','Difícil','Extrema']],['Animaciones de historia','anim',['No','Sí']],['Notificaciones de logros','ach',['No','Sí']],['Volver']];let si=0;
function setIn(){const n=SO.length,u=J.KeyW||J.ArrowUp,d=J.KeyS||J.ArrowDown,l=J.KeyA||J.ArrowLeft,r=J.KeyD||J.ArrowRight,ok=J.Enter||J.KeyF||J.KeyK;
 if(u){si=(si+n-1)%n;sfx('mv')}if(d){si=(si+1)%n;sfx('mv')}const o=SO[si];
 if(o[1]&&(l||r)){const v=l?-1:1;if(o[1]=='vol')CFG.vol=Math.round(Math.max(0,Math.min(1,CFG.vol+v*.1))*10)/10;else{const index=o[1]=='lang'?Math.max(0,LG.indexOf(CFG.lang)):CFG[o[1]],next=(index+v+o[2].length)%o[2].length;CFG[o[1]]=o[1]=='lang'?LG[next]:next}saveCfg();if(MG)MG.gain.value=CFG.vol;sfx('ok')}
 if(!o[1]&&ok){scr='menu';sfx('ok')}}
function drawSet(){bg();txt('AJUSTES',W/2,62,38,'#fff');const gp=navigator.getGamepads&&[...navigator.getGamepads()].some(x=>x&&x.connected);
 SO.forEach((o,i)=>{const y=100+i*35,on=i==si;g.fillStyle=on?'rgba(255,255,255,.25)':'rgba(10,8,20,.6)';rr(150,y,660,36,11);txt(o[0],174,y+24,17,on?'#ffd23c':'#f1ece4','left');
  if(o[1]=='difficulty'){const val=CFG.difficulty??1,x0=525,w=190;g.fillStyle='rgba(255,255,255,.2)';rr(x0,y+15,w,6,3);g.fillStyle='#ffd23c';rr(x0,y+15,w*val/3,6,3);for(let j=0;j<4;j++){g.fillStyle=j<=val?'#ffd23c':'#777';g.beginPath();g.arc(x0+w*j/3,y+18,5,0,7);g.fill()}txt(o[2][val],775,y+24,15,'#fff','right')}
  else if(o[1]){const val=o[1]=='vol'?Math.round(CFG.vol*100)+'%':o[1]=='lang'?o[2][Math.max(0,LG.indexOf(CFG.lang))]:o[2][CFG[o[1]]];txt((on?'◀  ':'')+val+(on?'  ▶':''),775,y+24,16,'#fff','right')}});
 txt(gp?'🎮 Mando detectado':'🎮 Sin mando: conecta uno para jugar',W/2,487,14,gp?'#6fcf6a':'#c9c1d8');txt('B confirma en mando · Esc vuelve',W/2,515,12,'#f1ece4')}
function drawOnlineWait(){bg();g.fillStyle='rgba(10,8,20,.76)';rr(190,100,580,340,24);txt('ONLINE DUEL',W/2,166,34,'#fff');g.strokeStyle='#78dcff';g.lineWidth=3;g.beginPath();g.arc(W/2,265,54+Math.sin(T*4)*5,T*2,T*2+Math.PI*1.6);g.stroke();txt(langText(onlineMessage||'Buscando rival...'),W/2,365,20,'#f1ece4');txt(langText('La sala empareja automáticamente a dos jugadores.'),W/2,402,14,'#c9c1d8');txt(langText('Esc cancela la búsqueda'),W/2,476,14,'#aaa')}
function wr(t,x,y,w){let l='',yy=y;g.font='20px "Trebuchet MS",sans-serif';g.textAlign='left';g.fillStyle='#fff';
 for(const wd of t.split(' ')){if(g.measureText(l+wd).width>w){g.fillText(l,x,yy);yy+=27;l=''}l+=wd+' '}g.fillText(l,x,yy)}
function drawStoryCrystal(){const x=480,y=224,pulse=1+Math.sin(T*3)*.08;g.save();g.translate(x,y);g.rotate(T*.32);g.shadowColor='#9ef7ff';g.shadowBlur=28;g.fillStyle='rgba(151,246,255,.2)';g.beginPath();g.moveTo(0,-44*pulse);g.lineTo(28,0);g.lineTo(0,44*pulse);g.lineTo(-28,0);g.closePath();g.fill();g.strokeStyle='#d5ffff';g.lineWidth=3;g.stroke();for(let i=0;i<8;i++){const a=i*Math.PI/4+T*.5,d=48+Math.sin(T*2+i)*12;g.globalAlpha=.5+.5*Math.abs(Math.sin(T*2+i));g.fillStyle=i%2?'#80dfff':'#fff4a6';g.beginPath();g.moveTo(Math.cos(a)*d,Math.sin(a)*d);g.lineTo(Math.cos(a+.22)*(d+13),Math.sin(a+.22)*(d+13));g.lineTo(Math.cos(a-.18)*(d+9),Math.sin(a-.18)*(d+9));g.closePath();g.fill()}g.globalAlpha=1;g.restore()}
function drawDlg(){bg();drawMap();g.fillStyle='rgba(7,5,20,.38)';g.fillRect(0,0,W,H);const[n,t,c]=dl[di],hero=sty&&CH[sel[0]],foe=sty&&CH[sty.ord[sty.ch]],beat=Math.sin(T*3.5);drawStoryCrystal();
 if(hero){const ha=n==hero.n,fa=foe&&n==foe.n,lx=224+(ha?12+Math.max(0,beat)*6:0),rx=736-(fa?12+Math.max(0,beat)*6:0);drawBody({x:lx-17,y:195+Math.sin(T*2)*3,w:34,h:50,f:1,vx:Math.sin(T*2)*1.2,vy:0,gr:1,act:ha&&Math.sin(T*4)>0.45?7:0,ty:'F',stun:0,dash:0,slam:0,up:0,sc:0,c:hero,ph:T*5,pw:ha?10:0},0,1,2.35);if(foe)drawBody({x:rx-17,y:195+Math.sin(T*2+1)*3,w:34,h:50,f:-1,vx:-Math.sin(T*2)*1.2,vy:0,gr:1,act:fa&&Math.sin(T*4+1)>0.45?7:0,ty:'F',stun:0,dash:0,slam:0,up:0,sc:0,c:foe,ph:T*5+1,pw:fa?10:0},0,1,2.35)}
 g.fillStyle='rgba(10,8,20,.92)';rr(38,355,884,157,18);g.fillStyle=c;rr(38,355,7,157,4);txt(n,65,391,21,c,'left');wr(langText(t).slice(0,dc|0),65,426,825);txt('Enter para continuar ▶',W-58,495,13,'#bbb','right');X.dlgFx(n,c,hero,foe)}
let last=0,acc=0;
function loop(t){requestAnimationFrame(loop);X.tick();T=t/1000;pollPad();music();acc+=Math.min(50,t-last);last=t;
 while(acc>=16.67){acc-=16.67;
  if(J.Escape&&scr!='menu'){if(onlineSocket)leaveOnline();scr='menu';sty=null;BOT=[0,0]}
  else if(scr=='menu')menuIn();
  else if(scr=='set')setIn();
  else if(scr=='sel')selInput();
  else if(scr=='dlg')dlgIn();
  else if(scr=='onlineWait'&&(J.Enter||J.KeyF||J.KeyK)&&!onlineSocket)connectOnline();
  else if(scr=='fight')step();
  else if(J.Enter||J.KeyF||J.KeyK)endNext();
  J={}}
 g.save();
 if(scr=='menu')drawMenu();else if(scr=='set')drawSet();else if(scr=='dlg')drawDlg();else if(scr=='sel')drawSel();else if(scr=='onlineWait')drawOnlineWait();
 else{if(shake>0)g.translate((Math.random()-.5)*shake*CFG.shk,(Math.random()-.5)*shake*CFG.shk);
  bg();drawMap();
  for(const b of B){g.globalAlpha=b.dl>0?.25:1;drawProjectile(b)}g.globalAlpha=1;
  drawIT();P.forEach(drawP);drawHZ();drawFX();g.restore();g.save();hud();
  if(MD.limit&&clock>0&&['points','king','timer'].includes(MD.k)){const secs=Math.ceil(clock/60),label=`${(secs/60|0)}:${String(secs%60).padStart(2,'0')}`;txt(label,W/2,42,28,secs<15?'#ff6b6b':'#fff')}
  if(MD.k=='king'){g.fillStyle='rgba(255,220,60,.1)';g.fillRect(390,0,180,H);txt('CIMA',480,80,13,'#ffe47a')}
  if(cdn>0){const n=Math.ceil(cdn/60),f=(cdn%60)/60;g.save();g.translate(W/2,H/2-10);g.scale(1+f*.45,1+f*.45);g.globalAlpha=.35+.65*(1-f);g.shadowColor='#000';g.shadowBlur=20;txt(n,0,40,130,['#fff','#ffd23c','#ff6b6b'][3-n]);g.restore()}
  else if(yaT>0){g.save();g.globalAlpha=Math.min(1,yaT/20);txt('¡YA!',W/2,H/2+30,110,'#6fcf6a');g.restore()}
  if(fs&&fs.t>0){g.fillStyle='rgba(0,0,0,.65)';g.fillRect(0,H/2-70,W,140);txt('¡SMASH FINAL!',W/2,H/2-22,22,'#fff');txt(fs.p.c.fn,W/2,H/2+30,54,fs.p.c.col)}
  if(scr=='end'){g.fillStyle='rgba(10,8,20,.7)';g.fillRect(0,0,W,H);
   txt(`¡Gana J${win.i+1} con ${win.c.n}!`,W/2,H/2-10,50,win.c.col);
   txt('Pulsa Enter para continuar',W/2,H/2+40,20,'#f1ece4');if(MD.k=='sv')txt('Racha: '+(SV+(win.i==0?1:0)),W/2,H/2+85,26,'#ffd23c');if(MD.k=='king')txt('Puntos cima: '+Math.floor(win.king/60),W/2,H/2+86,22,'#ffd23c');else if(MD.k=='points')txt('Puntuación: '+Math.floor(win.score),W/2,H/2+86,22,'#ffd23c');else if(MD.k=='timer')txt('Daño recibido: '+win.dmg.toFixed(0)+'%',W/2,H/2+86,22,'#ffd23c')}}
 g.restore()}
/* ===== EXTRAS: logros, desbloqueos, idiomas, animaciones de historia ===== */
CFG.ach??=1;CFG.anim??=1;
const XS=Object.assign({g:0,w:0,h:0,s:0,d:0,fl:0,sv:0,st:0,vs:0,vnd:0,vx:0,cw:{},sc:{},mw:{},used:{},dif:{},got:{}},(()=>{try{return JSON.parse(localStorage.getItem('dls')||'{}')}catch(e){return{}}})());
const CN=['Fuego','Rayo','Roca','Hielo','Sombra','Selva','Viento','Ninja','Astro','Vacío','Agua','Veneno','Acero','Luz'],PI=[0,1,2,3,4,5,6,7,8,10,11,12,13];
const MN={cpu:['Duelo CPU','CPU Duel'],timer:['Contrarreloj','Time Trial'],vs:['Versus','Versus'],sd:['Muerte súbita','Sudden Death'],sv:['Supervivencia','Survival']};
const AL=[],add=(id,es,en,f)=>AL.push({id,es,en,f}),tier=(k,a,es,en)=>a.forEach(n=>add(k+n,es(n),en(n),()=>XS[k]>=n));
PI.forEach(i=>{add('cw'+i,'Gana con '+CN[i],'Win with '+CN[i],()=>XS.cw[i]>0);add('sc'+i,'Historia con '+CN[i],'Story with '+CN[i],()=>XS.sc[i]>0)});
tier('w',[1,5,10,25,50,100,250,500],n=>n+' victorias',n=>n+' wins');
tier('g',[1,10,25,50,100,250,500],n=>n+' combates',n=>n+' matches');
tier('h',[50,250,1000,2500,5000,10000,25000,50000],n=>n+' golpes',n=>n+' hits landed');
tier('s',[10,50,100,250,500,1000,2500],n=>n+' especiales',n=>n+' specials');
tier('d',[100,1000,5000,10000,50000,100000],n=>n+' de daño',n=>n+' damage dealt');
tier('fl',[1,3,5,10,25],n=>n+' victorias perfectas',n=>n+' flawless wins');
tier('sv',[1,3,5,10,15,20,30],n=>'Racha '+n+' en Supervivencia',n=>'Survival streak '+n);
tier('st',[1,5,10],n=>'Historia completada ×'+n,n=>'Story cleared ×'+n);
for(const k in MN)[1,10].forEach(n=>add('m'+k+n,n+'× victoria: '+MN[k][0],n+'× win: '+MN[k][1],()=>(XS.mw[k]||0)>=n));
add('void1','Derrota a El Vacío','Defeat The Void',()=>XS.vs>0);add('void2','El Vacío sin recibir daño','Void without a scratch',()=>XS.vnd>0);add('void3','El Vacío en dificultad Extrema','Void on Extreme',()=>XS.vx>0);
[5,10,13].forEach(n=>add('u'+n,'Juega con '+n+' personajes','Play '+n+' characters',()=>Object.keys(XS.used).length>=n));
['Fácil','Normal','Difícil','Extrema'].forEach((d,i)=>add('dif'+i,'Historia en '+d,'Story on '+['Easy','Normal','Hard','Extreme'][i],()=>XS.dif[i]>0));
add('coll','Gana con todos los personajes','Win with every character',()=>PI.every(i=>XS.cw[i]>0));
add('unl','Desbloquea a todos','Unlock everyone',()=>Object.values(ULK).every(id=>XS.got[id]));
add('all','LEYENDA: 100% logros','LEGEND: 100% achievements',()=>AL.filter(a=>a.id!='all').every(a=>XS.got[a.id]));
const ULK={10:'w5',11:'st1',12:'w25',13:'sv5'};
const NW=[['Solitario',0,'Solo','Solo'],['Multijugador',0,'Multijoueur','Multijogador'],['Opciones',0,'Options','Opções'],['Historia',0,'Histoire','História'],['Duelo CPU',0,'Duel IA','Duelo CPU'],['Supervivencia',0,'Survie','Sobrevivência'],['Entrenamiento',0,'Entraînement','Treino'],['Contrarreloj',0,'Contre-la-montre','Contra o Relógio'],['Muerte súbita',0,'Mort subite','Morte súbita'],['Dificultad de historia',0,"Difficulté de l'histoire",'Dificuldade da história'],['Idioma',0,'Langue','Idioma'],['Volumen',0,'Volume','Volume'],['Música',0,'Musique','Música'],['Efectos de sonido',0,'Effets sonores','Efeitos sonoros'],['Objetos',0,'Objets','Itens'],['Volver',0,'Retour','Voltar'],['Fácil',0,'Facile','Fácil'],['Difícil',0,'Difficile','Difícil'],['Extrema',0,'Extrême','Extrema'],['Enter para continuar ▶',0,'Entrée pour continuer ▶','Enter para continuar ▶'],
['Duelo a muerte','Deathmatch','Duel à mort','Duelo mortal'],['Una vida contra la CPU','One life vs the CPU','Une vie contre l\'IA','Uma vida contra a CPU'],['Sin objetos','No items','Sans objets','Sem itens'],['Duelo CPU puro, sin objetos','Pure CPU duel, no items','Duel IA pur, sans objets','Duelo CPU puro, sem itens'],['Caos de objetos','Item Chaos','Chaos d\'objets','Caos de itens'],['Objetos sin parar','Non-stop items','Objets sans arrêt','Itens sem parar'],['Animaciones de historia','Story animations','Animations de l\'histoire','Animações da história'],['Notificaciones de logros','Achievement popups','Notifications de succès','Avisos de conquistas']];
const XL={fr:[],pt:[]};NW.forEach(([e,en,f,p])=>{if(en)EN_PAIRS.push([e,en]);XL.fr.push([e,f]);XL.pt.push([e,p])});for(const k in XL)XL[k].sort((a,b)=>b[0].length-a[0].length);
const LG=['es','en','fr','pt'];
SOLO.push({icon:'☠️',name:'Duelo a muerte',desc:'Una vida contra la CPU',k:'cpu',bot:1,st:1,it:380},{icon:'🧊',name:'Sin objetos',desc:'Duelo CPU puro, sin objetos',k:'cpu',bot:1,st:3,it:99999});
DUO.push({icon:'🎁',name:'Caos de objetos',desc:'Objetos sin parar',k:'vs',bot:0,st:3,it:80});
const ES=(o)=>Object.assign(document.createElement('div'),o);
const st_=document.head.appendChild(document.createElement('style'));st_.textContent='#ach{position:fixed;top:-90px;left:50%;transform:translateX(-50%);z-index:40;background:linear-gradient(135deg,#ffd23c,#ff8a2a);color:#1a1020;font:700 15px Trebuchet MS,sans-serif;padding:10px 18px;border-radius:14px;box-shadow:0 6px 24px #000a;transition:top .45s cubic-bezier(.2,1.6,.4,1);pointer-events:none;text-align:center}#ach.on{top:calc(env(safe-area-inset-top,0px) + 10px)}#ach small{display:block;font-weight:600;opacity:.8}#tb{position:fixed;top:calc(env(safe-area-inset-top,0px) + 6px);left:6px;z-index:30;font-size:20px;background:#0008;color:#fff;border:1px solid #fff4;border-radius:10px;padding:4px 8px}#ap{display:none;position:fixed;inset:0;z-index:50;background:#120f1ff2;color:#f1ece4;font:14px Trebuchet MS,sans-serif;overflow:auto;padding:14px}#ap.on{display:block}#ap .gr{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:6px}#ap .a{padding:7px 10px;border-radius:8px;background:#ffffff12;opacity:.45}#ap .a.y{opacity:1;background:#ffd23c33}';
const tb=ES({id:'tb',textContent:'🏆'}),ap=ES({id:'ap'}),an=ES({id:'ach'});tb.tagName;document.body.append(tb,ap,an);
const X={q:[],busy:0,
 en:()=>CFG.lang!='es',
 pop(a,b){X.q.push([a,b]);if(!X.busy)X.next()},
 next(){const n=X.q.shift();if(!n){X.busy=0;return}X.busy=1;an.innerHTML=n[0]+'<small>'+n[1]+'</small>';an.className='on';sfx('it');setTimeout(()=>{an.className='';setTimeout(()=>X.next(),500)},2600)},
 save(){try{localStorage.setItem('dls',JSON.stringify(XS))}catch(e){}},
 chk(){AL.forEach(a=>{if(!XS.got[a.id]&&a.f()){XS.got[a.id]=1;if(CFG.ach)X.pop('🏆 '+(X.en()?a.en:a.es),X.en()?'Achievement unlocked':'Logro desbloqueado')}});X.save()},
 ok:i=>!ULK[i]||XS.got[ULK[i]],
 hit(t,d){if(!onlineActive&&A&&A.i==0&&A!==t){XS.h++;XS.d+=d|0}},
 sp(p){if(!onlineActive&&p.i==0)XS.s++},
 end(w){if(onlineActive||!w)return;XS.g++;const h=sel[0];XS.used[h]=1;if(w.i==0){XS.w++;XS.cw[h]=(XS.cw[h]||0)+1;if(w.dmg<=0)XS.fl++;XS.mw[MD.k]=(XS.mw[MD.k]||0)+1;if(sty&&sty.ord[sty.ch]==9){XS.vs=1;if(w.dmg<=0)XS.vnd=1;if(CFG.difficulty==3)XS.vx=1}}X.chk()},
 story(){XS.st++;XS.sc[sel[0]]=1;XS.dif[CFG.difficulty??1]=1;X.chk()},
 sv(n){XS.sv=Math.max(XS.sv,n);X.chk()},
 tick(){if(scr=='sel'&&MD.k!='online')for(const i of[0,1])if(rdy[i]&&!(i==1&&BOT[1])&&!X.ok(sel[i])){rdy[i]=0;sfx('hit');const a=AL.find(a=>a.id==ULK[sel[i]]);X.pop('🔒 '+CN[sel[i]],(X.en()?'Unlock: ':'Desbloquea: ')+(X.en()?a.en:a.es))}},
 panel(){const on=ap.classList.toggle('on');if(!on)return;const n=AL.filter(a=>XS.got[a.id]).length;ap.innerHTML='<h2>🏆 '+(X.en()?'Achievements':'Logros')+' '+n+'/'+AL.length+' <button onclick="this.parentNode.parentNode.classList.remove(\'on\')">✕</button></h2><div class="gr">'+AL.map(a=>'<div class="a'+(XS.got[a.id]?' y':'')+'">'+(XS.got[a.id]?'✅ ':'🔒 ')+(X.en()?a.en:a.es)+'</div>').join('')+'</div>'},
 t0:0,dl_:null,di_:-1,
 dlgFx(n,c,hero,foe){if(dl!=X.dl_||di!=X.di_){X.dl_=dl;X.di_=di;X.t0=T}if(!CFG.anim)return;const e=Math.min(1,(T-X.t0)/.6),sx=hero&&n==hero.n?224:foe&&n==foe.n?736:W/2,sy=235;g.save();
  for(let i=0;i<18;i++){const x=(i*97+T*(18+i%3*9))%W,y=(i*61+T*(30+i%4*8))%350;g.fillStyle='rgba(158,247,255,.3)';g.beginPath();g.moveTo(x,y-6);g.lineTo(x+4,y);g.lineTo(x,y+6);g.lineTo(x-4,y);g.fill()}
  if(foe&&foe===CH[9]){const v=g.createRadialGradient(W/2,250,150,W/2,250,560);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(120,0,40,'+(.35+Math.sin(T*3)*.15)+')');g.fillStyle=v;g.fillRect(0,0,W,H)}
  g.globalCompositeOperation='lighter';for(let i=0;i<16;i++){const a=T*(1.2+i%3*.4)+i*.4,r=55+(i*13)%30+Math.sin(T*3+i)*8;g.globalAlpha=.55;g.fillStyle=c;g.beginPath();g.arc(sx+Math.cos(a)*r,sy+Math.sin(a)*r*1.3,2+i%3,0,7);g.fill()}
  const rr_=(T-X.t0)*240;g.globalAlpha=Math.max(0,1-rr_/260);g.strokeStyle=c;g.lineWidth=4;g.beginPath();g.arc(sx,sy,rr_,0,7);g.stroke();g.globalAlpha=(1-e)*.5;g.fillStyle='#fff';g.fillRect(0,0,W,H);
  g.globalCompositeOperation='source-over';g.globalAlpha=1;g.fillStyle='#000';g.fillRect(0,0,W,34*(1-(1-e)**3));g.restore()}};
tb.onpointerup=()=>X.panel();addEventListener('keydown',e=>{if(e.code=='KeyT'&&scr!='fight')X.panel()});
X.chk();

applyCfg();syncLanguage();requestAnimationFrame(loop);
