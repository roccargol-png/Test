# Cumbre II – online mode

    node online-server.js        # needs Node 18+, no npm install
    # open http://localhost:8080 in two tabs/devices -> Multijugador -> Online

- PORT=3000 node online-server.js   changes the port.
- To play over the internet, run it on any host that supports Node + WebSockets
  (Render, Railway, Fly.io, a VPS...) and share the URL, or tunnel your machine
  (e.g. cloudflared / ngrok) -> both players open the public URL.
- Game hosted separately from the server? Add ?ws=wss://your-server/ws to the game URL.
- On Websim the built-in WebsimSocket is still used automatically.
